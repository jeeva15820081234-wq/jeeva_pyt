/**
 * Mooshika: The Festival Guardian - Main Application
 * A complete, polished, playable 2D browser game inspired by Vinayagar Chavurthi.
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { GameState, PlayerStats, LevelProgress, Achievement } from './game/types';
import { INITIAL_ACHIEVEMENTS } from './game/constants';
import { LEVELS } from './game/levelsData';
import { GameEngine, InputState } from './game/engine';
import { sound } from './game/sound';

import { GameCanvas } from './components/GameCanvas';
import { GameHUD } from './components/GameHUD';
import { MobileControls } from './components/MobileControls';
import { MainMenu } from './components/MainMenu';
import { StoryIntroModal } from './components/StoryIntroModal';
import { LevelSelectModal } from './components/LevelSelectModal';
import { PauseModal } from './components/PauseModal';
import { LevelCompleteModal } from './components/LevelCompleteModal';
import { GameOverModal } from './components/GameOverModal';
import { VictoryModal } from './components/VictoryModal';
import { AchievementsModal } from './components/AchievementsModal';

const STORAGE_KEYS = {
  PROGRESS: 'mooshika_progress_v1',
  ACHIEVEMENTS: 'mooshika_achievements_v1',
  STATS: 'mooshika_stats_v1',
  TOUCH_CONTROLS: 'mooshika_touch_controls_v1',
};

export default function App() {
  const [gameState, setGameState] = useState<GameState>('menu');
  const [currentLevelId, setCurrentLevelId] = useState<number>(1);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Centralized input state ref for synchronous game loop updates (keyboard + mobile touch)
  const inputRef = useRef<InputState>({
    left: false,
    right: false,
    up: false,
    down: false,
    jump: false,
    dash: false,
    special: false,
  });

  // Responsive touch controls visibility (defaults to true on mobile/touch screens)
  const [showTouchControls, setShowTouchControls] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.TOUCH_CONTROLS);
      if (saved !== null) return saved === 'true';
    } catch {
      // Ignore
    }
    if (typeof window === 'undefined') return false;
    return (
      'ontouchstart' in window ||
      (navigator.maxTouchPoints && navigator.maxTouchPoints > 0) ||
      window.innerWidth <= 1024
    );
  });

  // Mobile portrait orientation helper
  const [isPortrait, setIsPortrait] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return window.innerHeight > window.innerWidth && window.innerWidth < 800;
  });

  useEffect(() => {
    const handleResize = () => {
      setIsPortrait(window.innerHeight > window.innerWidth && window.innerWidth < 800);
    };
    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
    };
  }, []);

  const handleToggleTouchControls = useCallback(() => {
    setShowTouchControls(prev => {
      const next = !prev;
      try {
        localStorage.setItem(STORAGE_KEYS.TOUCH_CONTROLS, String(next));
      } catch {
        // Ignore
      }
      return next;
    });
  }, []);

  // Player persistent stats
  const [stats, setStats] = useState<PlayerStats>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.STATS);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return {
      score: 0,
      highScore: 0,
      coins: 0,
      totalModakas: 0,
      totalBells: 0,
      lives: 3,
      maxLives: 3,
      health: 3,
      maxHealth: 3,
      festivalEnergy: 100,
      maxFestivalEnergy: 100,
      combo: 1,
      comboTimer: 0,
      maxCombo: 1,
    };
  });

  // Level progression
  const [progress, setProgress] = useState<LevelProgress[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PROGRESS);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return LEVELS.map(lvl => ({
      levelId: lvl.id,
      unlocked: lvl.id === 1,
      completed: false,
      stars: 0,
      highScore: 0,
      modakasCollected: 0,
      totalModakas: 3,
      bestTime: 0,
    }));
  });

  // Achievements
  const [achievements, setAchievements] = useState<Achievement[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ACHIEVEMENTS);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return INITIAL_ACHIEVEMENTS;
  });

  // Current active level complete state info
  const [levelEndInfo, setLevelEndInfo] = useState<{ stars: number; score: number }>({
    stars: 1,
    score: 0,
  });

  // Active GameEngine reference
  const engineRef = useRef<GameEngine | null>(null);

  // Save to localStorage on change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PROGRESS, JSON.stringify(progress));
      localStorage.setItem(STORAGE_KEYS.ACHIEVEMENTS, JSON.stringify(achievements));
      localStorage.setItem(STORAGE_KEYS.STATS, JSON.stringify(stats));
    } catch {
      // Ignore
    }
  }, [progress, achievements, stats]);

  // Sound Mute Toggle
  const handleToggleMute = useCallback(() => {
    const muted = sound.toggleMute();
    setIsMuted(muted);
  }, []);

  // Initialize and start a level
  const startLevel = useCallback((levelId: number) => {
    const levelData = LEVELS.find(l => l.id === levelId) || LEVELS[0];
    setCurrentLevelId(levelId);

    // Reset health & combo for level start
    setStats(prev => ({
      ...prev,
      health: prev.maxHealth,
      combo: 1,
      comboTimer: 0,
      festivalEnergy: Math.max(50, prev.festivalEnergy),
    }));

    const newEngine = new GameEngine(levelData, stats, progress, achievements);

    newEngine.onLevelComplete = (stars, score) => {
      setLevelEndInfo({ stars, score });
      if (levelId === 10) {
        setGameState('victory');
      } else {
        setGameState('level_complete');
      }
    };

    newEngine.onGameOver = () => {
      setGameState('game_over');
    };

    newEngine.onAchievementUnlocked = (ach) => {
      setAchievements(prev =>
        prev.map(a => (a.id === ach.id ? { ...a, unlocked: true, unlockedAt: Date.now() } : a))
      );
    };

    engineRef.current = newEngine;
    setGameState('playing');
    sound.startMusic();
  }, [achievements, progress, stats]);

  // Restart current level
  const handleRestartLevel = useCallback(() => {
    startLevel(currentLevelId);
  }, [currentLevelId, startLevel]);

  // Next level
  const handleNextLevel = useCallback(() => {
    if (currentLevelId < 10) {
      startLevel(currentLevelId + 1);
    } else {
      setGameState('victory');
    }
  }, [currentLevelId, startLevel]);

  // Main Menu start game (starts at latest unlocked level)
  const handleStartGameFromMenu = useCallback(() => {
    // Find latest unlocked level
    const latestUnlocked = [...progress].reverse().find(p => p.unlocked)?.levelId || 1;
    startLevel(latestUnlocked);
  }, [progress, startLevel]);

  const currentLevelData = LEVELS.find(l => l.id === currentLevelId) || LEVELS[0];

  return (
    <main id="app-root" className="relative w-screen h-screen overflow-hidden bg-black flex items-center justify-center font-sans select-none">
      {/* 1. Game Canvas (Always rendered when playing or paused or ending level) */}
      {engineRef.current && (
        <GameCanvas
          engine={engineRef.current}
          isPaused={gameState === 'paused'}
          inputRef={inputRef}
          onPauseToggle={() => {
            if (gameState === 'playing') setGameState('paused');
            else if (gameState === 'paused') setGameState('playing');
          }}
        />
      )}

      {/* 2. In-Game HUD (Visible during gameplay and pause) */}
      {(gameState === 'playing' || gameState === 'paused') && engineRef.current && (
        <GameHUD
          stats={engineRef.current.stats}
          levelTitle={currentLevelData.title}
          levelNumber={currentLevelData.id}
          objective={currentLevelData.objective}
          levelModakasFound={engineRef.current.levelModakasFound}
          totalLevelModakas={3}
          activePowerUps={engineRef.current.activePowerUps}
          activeBoss={engineRef.current.activeBoss}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
          onPause={() => setGameState('paused')}
          showTouchControls={showTouchControls}
          onToggleTouchControls={handleToggleTouchControls}
        />
      )}

      {/* 3. Mobile Touch Controls (Rendered on top of canvas and HUD when playing or paused) */}
      {(gameState === 'playing' || gameState === 'paused') && showTouchControls && (
        <MobileControls inputRef={inputRef} />
      )}

      {/* 4. Portrait orientation suggestion banner */}
      {(gameState === 'playing' || gameState === 'paused') && isPortrait && (
        <div
          id="mobile-orientation-hint"
          className="absolute top-14 left-1/2 -translate-x-1/2 pointer-events-none bg-black/75 backdrop-blur-md text-amber-200 text-[11px] px-3 py-1 rounded-full border border-amber-500/30 flex items-center gap-1.5 z-30 shadow-lg animate-pulse whitespace-nowrap"
        >
          <span>🔄 Rotate phone to landscape for optimal view</span>
        </div>
      )}

      {/* 5. Main Menu Overlay */}
      {gameState === 'menu' && (
        <MainMenu
          onStartGame={handleStartGameFromMenu}
          onOpenStory={() => setGameState('story')}
          onOpenLevelSelect={() => setGameState('level_select')}
          onOpenAchievements={() => setGameState('achievements')}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
          showTouchControls={showTouchControls}
          onToggleTouchControls={handleToggleTouchControls}
        />
      )}

      {/* 6. Story Intro Modal */}
      {gameState === 'story' && (
        <StoryIntroModal
          onStartGame={handleStartGameFromMenu}
          onClose={() => setGameState('menu')}
        />
      )}

      {/* 7. Level Select Modal */}
      {gameState === 'level_select' && (
        <LevelSelectModal
          progress={progress}
          onSelectLevel={id => startLevel(id)}
          onClose={() => setGameState('menu')}
        />
      )}

      {/* 8. Pause Modal */}
      {gameState === 'paused' && (
        <PauseModal
          onResume={() => setGameState('playing')}
          onRestart={handleRestartLevel}
          onLevelSelect={() => setGameState('level_select')}
          onMainMenu={() => {
            sound.stopMusic();
            setGameState('menu');
          }}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
          levelTitle={`Level ${currentLevelData.id}: ${currentLevelData.title}`}
          showTouchControls={showTouchControls}
          onToggleTouchControls={handleToggleTouchControls}
        />
      )}

      {/* 7. Level Complete Modal */}
      {gameState === 'level_complete' && (
        <LevelCompleteModal
          levelNumber={currentLevelData.id}
          levelTitle={currentLevelData.title}
          stars={levelEndInfo.stars}
          score={levelEndInfo.score}
          modakasFound={engineRef.current?.levelModakasFound || 0}
          totalModakas={3}
          hasNextLevel={currentLevelId < 10}
          onNextLevel={handleNextLevel}
          onReplay={handleRestartLevel}
          onLevelSelect={() => setGameState('level_select')}
        />
      )}

      {/* 8. Game Over Modal */}
      {gameState === 'game_over' && (
        <GameOverModal
          onRestart={handleRestartLevel}
          onLevelSelect={() => setGameState('level_select')}
          onMainMenu={() => {
            sound.stopMusic();
            setGameState('menu');
          }}
        />
      )}

      {/* 9. Final Festival Victory Celebration Modal */}
      {gameState === 'victory' && (
        <VictoryModal
          stats={stats}
          progress={progress}
          achievements={achievements}
          onPlayAgain={() => startLevel(1)}
          onMainMenu={() => {
            sound.stopMusic();
            setGameState('menu');
          }}
        />
      )}

      {/* 10. Achievements Modal */}
      {gameState === 'achievements' && (
        <AchievementsModal
          achievements={achievements}
          onClose={() => setGameState('menu')}
        />
      )}
    </main>
  );
}
