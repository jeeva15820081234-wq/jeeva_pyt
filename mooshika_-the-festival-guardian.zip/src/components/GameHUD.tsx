/**
 * Mooshika: The Festival Guardian - In-Game HUD
 */

import React from 'react';
import { PlayerStats, ActivePowerUp, Enemy } from '../game/types';
import { Heart, Pause, Volume2, VolumeX, Sparkles, Shield, Zap, Gamepad2 } from 'lucide-react';

interface GameHUDProps {
  stats: PlayerStats;
  levelTitle: string;
  levelNumber: number;
  objective: string;
  levelModakasFound: number;
  totalLevelModakas: number;
  activePowerUps: ActivePowerUp[];
  activeBoss: Enemy | null;
  isMuted: boolean;
  onToggleMute: () => void;
  onPause: () => void;
  showTouchControls?: boolean;
  onToggleTouchControls?: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  stats,
  levelTitle,
  levelNumber,
  objective,
  levelModakasFound,
  totalLevelModakas,
  activePowerUps,
  activeBoss,
  isMuted,
  onToggleMute,
  onPause,
  showTouchControls,
  onToggleTouchControls,
}) => {
  return (
    <div id="game-hud" className="absolute inset-0 pointer-events-none p-2 sm:p-4 flex flex-col justify-between select-none">
      {/* Top Bar */}
      <div className="flex items-start justify-between gap-1.5 sm:gap-2">
        {/* Top Left: Health, Lives, Score, Combo */}
        <div className="flex flex-col gap-1 sm:gap-1.5">
          {/* Health Hearts */}
          <div className="flex items-center gap-1 bg-black/65 backdrop-blur-md px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full border border-amber-500/30">
            {Array.from({ length: stats.maxHealth }).map((_, i) => (
              <Heart
                key={i}
                size={16}
                className={`transition-transform duration-200 ${
                  i < stats.health
                    ? 'fill-rose-500 text-rose-500 scale-100 drop-shadow-[0_0_6px_rgba(244,63,94,0.7)]'
                    : 'text-zinc-600 fill-zinc-800 scale-90'
                }`}
              />
            ))}
            <span className="text-xs font-bold text-amber-200 ml-1.5 border-l border-amber-500/30 pl-1.5">
              🐾 ×{stats.lives}
            </span>
          </div>

          {/* Score & Combo */}
          <div className="flex items-center gap-2">
            <div className="bg-black/65 backdrop-blur-md px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-full border border-amber-500/30 flex items-center gap-1.5">
              <span className="text-amber-400 text-xs font-bold">⭐</span>
              <span className="text-xs sm:text-sm font-extrabold text-white tracking-wider font-mono">
                {stats.score.toLocaleString()}
              </span>
            </div>

            {stats.combo > 1 && (
              <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-black px-2 py-0.5 rounded-full font-black text-[11px] animate-bounce shadow-[0_0_12px_rgba(245,158,11,0.6)]">
                {stats.combo}×
              </div>
            )}
          </div>
        </div>

        {/* Top Center: Objective & Level Info (Hidden on small mobile to save space) */}
        <div className="hidden md:flex flex-col items-center text-center max-w-md bg-black/65 backdrop-blur-md px-4 py-1.5 rounded-2xl border border-amber-500/30">
          <div className="text-amber-400 font-extrabold text-xs uppercase tracking-widest font-festive">
            Level {levelNumber}: {levelTitle}
          </div>
          <div className="text-white/90 text-xs font-medium truncate max-w-xs">
            {objective}
          </div>
        </div>

        {/* Top Right: Collectibles & Buttons */}
        <div className="flex flex-col items-end gap-1 sm:gap-1.5">
          {/* Collectible Counters */}
          <div className="flex items-center gap-1.5 sm:gap-2 bg-black/65 backdrop-blur-md px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full border border-amber-500/30">
            {/* Modakas */}
            <div className="flex items-center gap-1" title="Sacred Modakas">
              <span className="text-xs sm:text-sm">🍬</span>
              <span className="text-[11px] sm:text-xs font-bold text-amber-300">
                {levelModakasFound}/{totalLevelModakas}
              </span>
            </div>

            {/* Bells */}
            <div className="flex items-center gap-1 ml-0.5" title="Festival Bells">
              <span className="text-xs sm:text-sm">🔔</span>
              <span className="text-[11px] sm:text-xs font-bold text-amber-300">
                {stats.totalBells}
              </span>
            </div>

            {/* Coins */}
            <div className="flex items-center gap-1 ml-0.5" title="Coins">
              <span className="text-xs sm:text-sm">💰</span>
              <span className="text-[11px] sm:text-xs font-bold text-amber-300">
                {stats.coins}
              </span>
            </div>
          </div>

          {/* Festival Energy Meter & Quick Action Buttons */}
          <div className="flex items-center gap-1.5 sm:gap-2 pointer-events-auto">
            {/* Festival Energy Bar */}
            <div className="bg-black/65 backdrop-blur-md px-2 sm:px-2.5 py-1 rounded-full border border-amber-500/30 flex items-center gap-1" title="Festival Energy (Press Bell button for blast)">
              <Zap size={13} className="text-yellow-400 fill-yellow-400" />
              <div className="w-12 sm:w-16 h-2 bg-zinc-800 rounded-full overflow-hidden border border-yellow-500/30">
                <div
                  className="h-full bg-gradient-to-r from-amber-400 to-yellow-300 transition-all duration-200"
                  style={{ width: `${(stats.festivalEnergy / stats.maxFestivalEnergy) * 100}%` }}
                />
              </div>
            </div>

            {/* On-Screen Controls Toggle Button */}
            {onToggleTouchControls && (
              <button
                type="button"
                id="hud-touch-controls-btn"
                onClick={onToggleTouchControls}
                className={`p-1.5 sm:p-2 rounded-full border transition-all active:scale-90 flex items-center justify-center ${
                  showTouchControls
                    ? 'bg-amber-500/40 text-amber-200 border-amber-400 shadow-[0_0_10px_rgba(245,158,11,0.5)]'
                    : 'bg-black/65 hover:bg-black/85 text-zinc-400 border-zinc-700'
                }`}
                title={showTouchControls ? 'Hide Touch Controls' : 'Show Touch Controls'}
                aria-label="Toggle Touch Controls"
              >
                <Gamepad2 size={16} />
              </button>
            )}

            {/* Sound Toggle */}
            <button
              type="button"
              id="hud-mute-btn"
              onClick={onToggleMute}
              className="p-1.5 sm:p-2 bg-black/65 hover:bg-black/85 text-amber-300 rounded-full border border-amber-500/30 transition-all active:scale-90 flex items-center justify-center"
              title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
              aria-label="Toggle Mute"
            >
              {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
            </button>

            {/* Pause Button */}
            <button
              type="button"
              id="hud-pause-btn"
              onClick={onPause}
              className="p-1.5 sm:p-2 bg-black/65 hover:bg-black/85 text-amber-300 rounded-full border border-amber-500/30 transition-all active:scale-90 flex items-center justify-center"
              title="Pause Game (ESC)"
              aria-label="Pause"
            >
              <Pause size={16} />
            </button>
          </div>
        </div>
      </div>

      {/* Middle Center: Boss Health Bar (if boss present and active) */}
      {activeBoss && !activeBoss.isDefeated && (
        <div className="self-center flex flex-col items-center gap-1 bg-black/70 backdrop-blur-md px-6 py-2 rounded-2xl border border-purple-500/50 shadow-[0_0_20px_rgba(147,51,234,0.4)] animate-pulse">
          <div className="text-purple-300 text-xs font-extrabold uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles size={13} className="text-purple-400" />
            {activeBoss.bossName || 'Shadow Guardian'}
          </div>
          <div className="w-48 sm:w-64 h-3 bg-zinc-900 rounded-full overflow-hidden border border-purple-400/40 p-0.5">
            <div
              className="h-full bg-gradient-to-r from-purple-600 via-rose-500 to-amber-400 rounded-full transition-all duration-300"
              style={{ width: `${(activeBoss.health / activeBoss.maxHealth) * 100}%` }}
            />
          </div>
        </div>
      )}

      {/* Bottom Center: Active Power-up Badges */}
      <div className="self-center flex items-center gap-2 mb-2">
        {activePowerUps.map(p => (
          <div
            key={p.type}
            className="flex items-center gap-1.5 bg-black/75 backdrop-blur-md px-3 py-1 rounded-full border border-amber-400/60 shadow-[0_0_12px_rgba(251,191,36,0.3)] animate-bounce"
          >
            {p.type === 'lotus_shield' && <Shield size={14} className="text-pink-400 fill-pink-400" />}
            {p.type === 'modaka_power' && <Zap size={14} className="text-amber-400 fill-amber-400" />}
            {p.type === 'festival_dash' && <Sparkles size={14} className="text-orange-400 fill-orange-400" />}
            {p.type === 'golden_bell' && <span className="text-xs">🔔</span>}
            {p.type === 'divine_light' && <span className="text-xs">✨</span>}
            <span className="text-xs font-bold text-white capitalize">
              {p.type.replace('_', ' ')} ({Math.ceil(p.duration)}s)
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
