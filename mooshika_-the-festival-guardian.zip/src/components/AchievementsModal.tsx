/**
 * Mooshika: The Festival Guardian - Achievements Modal
 */

import React from 'react';
import { Achievement } from '../game/types';
import { Trophy, CheckCircle, Lock, X } from 'lucide-react';

interface AchievementsModalProps {
  achievements: Achievement[];
  onClose: () => void;
}

export const AchievementsModal: React.FC<AchievementsModalProps> = ({
  achievements,
  onClose,
}) => {
  const unlockedCount = achievements.filter(a => a.unlocked).length;

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md select-none">
      <div className="relative w-full max-w-xl bg-[#170c29] border-2 border-amber-500/40 rounded-3xl p-6 sm:p-7 shadow-[0_0_50px_rgba(245,158,11,0.25)] max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-amber-500/20">
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-amber-300 font-festive flex items-center gap-2">
              <Trophy size={26} className="text-amber-400" />
              <span>Divine Achievements</span>
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              Unlocked: <strong className="text-amber-300">{unlockedCount} of {achievements.length}</strong>
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-white rounded-full bg-white/5 hover:bg-white/10 transition-all cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* List of achievements */}
        <div className="flex flex-col gap-2.5 my-4 overflow-y-auto pr-1">
          {achievements.map(ach => (
            <div
              key={ach.id}
              className={`p-3.5 rounded-2xl border flex items-center gap-3.5 transition-all ${
                ach.unlocked
                  ? 'bg-gradient-to-r from-amber-500/15 to-transparent border-amber-500/40'
                  : 'bg-zinc-900/40 border-zinc-800 opacity-60'
              }`}
            >
              <div className="text-3xl p-2 rounded-2xl bg-black/40 border border-white/5 flex items-center justify-center w-14 h-14 shrink-0">
                {ach.icon}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="font-festive font-extrabold text-base text-white truncate">
                    {ach.title}
                  </h3>
                  {ach.unlocked ? (
                    <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20 shrink-0">
                      <CheckCircle size={12} />
                      <span>Unlocked</span>
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-[11px] font-medium text-zinc-500 bg-zinc-800/40 px-2 py-0.5 rounded-full border border-zinc-700/40 shrink-0">
                      <Lock size={11} />
                      <span>Locked</span>
                    </span>
                  )}
                </div>
                <p className="text-xs text-zinc-300 mt-0.5">
                  {ach.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
