/**
 * Mooshika: The Festival Guardian - Game Over Modal
 */

import React from 'react';
import { RotateCcw, Map, Home } from 'lucide-react';

interface GameOverModalProps {
  onRestart: () => void;
  onLevelSelect: () => void;
  onMainMenu: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  onRestart,
  onLevelSelect,
  onMainMenu,
}) => {
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md select-none">
      <div className="w-full max-w-sm bg-gradient-to-b from-[#240e2d] to-[#120718] border-2 border-rose-500/40 rounded-3xl p-6 sm:p-8 shadow-[0_0_40px_rgba(244,63,94,0.25)] flex flex-col items-center text-center">
        <div className="text-4xl mb-3 animate-pulse">
          🐭✨
        </div>

        <h2 className="text-3xl font-extrabold text-amber-300 font-festive mb-2">
          Mooshika Needs Rest
        </h2>

        <p className="text-xs sm:text-sm text-zinc-300 mb-6 leading-relaxed">
          The shadows were tricky, but Lord Vinayagar’s blessing is always with Mooshika! Rise again and reclaim the festival sweets.
        </p>

        <div className="flex flex-col gap-2.5 w-full">
          {/* Try Again */}
          <button
            onClick={onRestart}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black font-extrabold text-base flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(245,158,11,0.4)] active:scale-95 transition-all cursor-pointer"
          >
            <RotateCcw size={18} />
            <span>Try Again</span>
          </button>

          {/* Level Select */}
          <button
            onClick={onLevelSelect}
            className="w-full py-2.5 rounded-2xl bg-white/5 hover:bg-white/10 text-white font-semibold text-sm flex items-center justify-center gap-2 border border-white/10 active:scale-95 transition-all cursor-pointer"
          >
            <Map size={16} />
            <span>Select Level</span>
          </button>

          {/* Main Menu */}
          <button
            onClick={onMainMenu}
            className="w-full py-2.5 rounded-2xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white font-medium text-xs flex items-center justify-center gap-2 transition-all cursor-pointer mt-1"
          >
            <Home size={14} />
            <span>Return to Menu</span>
          </button>
        </div>
      </div>
    </div>
  );
};
