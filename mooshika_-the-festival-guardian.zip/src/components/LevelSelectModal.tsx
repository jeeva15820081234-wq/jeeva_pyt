/**
 * Mooshika: The Festival Guardian - Level Select Modal
 */

import React from 'react';
import { LevelProgress } from '../game/types';
import { LEVELS } from '../game/levelsData';
import { Lock, Star, Play, X, Trophy } from 'lucide-react';

interface LevelSelectModalProps {
  progress: LevelProgress[];
  onSelectLevel: (levelId: number) => void;
  onClose: () => void;
}

export const LevelSelectModal: React.FC<LevelSelectModalProps> = ({
  progress,
  onSelectLevel,
  onClose,
}) => {
  // Calculate overall game completion %
  const totalStars = progress.reduce((acc, p) => acc + p.stars, 0);
  const maxPossibleStars = LEVELS.length * 3;
  const completionPercentage = Math.round((totalStars / maxPossibleStars) * 100);

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md select-none overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-[#170c29] border-2 border-amber-500/30 rounded-3xl p-5 sm:p-7 shadow-[0_0_50px_rgba(245,158,11,0.2)] max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-amber-500/20">
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-amber-300 font-festive flex items-center gap-2">
              <span>Festival Journey</span>
              <span className="text-sm font-sans font-bold bg-amber-500/20 text-amber-300 px-2.5 py-0.5 rounded-full border border-amber-500/30">
                {completionPercentage}% Saved
              </span>
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              10 sacred lands to purify • Collect all 3 Modakas in each level for 3 stars!
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-white rounded-full bg-white/5 hover:bg-white/10 transition-all cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* Level Cards Grid (10 Levels) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5 my-4 overflow-y-auto pr-1">
          {LEVELS.map(lvl => {
            const prog = progress.find(p => p.levelId === lvl.id) || {
              levelId: lvl.id,
              unlocked: lvl.id === 1,
              completed: false,
              stars: 0,
              highScore: 0,
              modakasCollected: 0,
              totalModakas: 3,
              bestTime: 0,
            };

            const isLocked = !prog.unlocked;

            return (
              <div
                key={lvl.id}
                onClick={() => {
                  if (!isLocked) onSelectLevel(lvl.id);
                }}
                className={`relative rounded-2xl p-3.5 flex flex-col justify-between border transition-all duration-200 ${
                  isLocked
                    ? 'bg-zinc-900/50 border-zinc-800 opacity-60 cursor-not-allowed'
                    : 'bg-gradient-to-b from-[#251240] to-[#160a27] border-amber-500/40 hover:border-amber-400 hover:shadow-[0_0_20px_rgba(245,158,11,0.3)] hover:-translate-y-1 cursor-pointer active:scale-95'
                }`}
              >
                {/* Level Number & Environment Badge */}
                <div className="flex items-center justify-between mb-2">
                  <span className="w-7 h-7 rounded-full bg-amber-500/20 border border-amber-500/30 text-amber-300 font-extrabold text-xs flex items-center justify-center font-mono">
                    {lvl.id}
                  </span>
                  {isLocked ? (
                    <Lock size={14} className="text-zinc-500" />
                  ) : prog.completed ? (
                    <span className="text-xs text-emerald-400 font-bold">Done ✓</span>
                  ) : (
                    <span className="text-xs text-amber-400 font-medium">Ready</span>
                  )}
                </div>

                {/* Level Title & Subtitle */}
                <div className="mb-3">
                  <h3 className="font-festive font-extrabold text-sm sm:text-base text-white truncate">
                    {lvl.title}
                  </h3>
                  <p className="text-[11px] text-amber-200/70 truncate">
                    {lvl.subtitle}
                  </p>
                </div>

                {/* Stars Rating (0 - 3) */}
                <div className="flex items-center gap-1 my-1">
                  {[1, 2, 3].map(s => (
                    <Star
                      key={s}
                      size={14}
                      className={
                        s <= prog.stars
                          ? 'fill-amber-400 text-amber-400 drop-shadow-[0_0_4px_rgba(251,191,36,0.6)]'
                          : 'text-zinc-700 fill-zinc-800'
                      }
                    />
                  ))}
                </div>

                {/* Stats: Modakas & Best Score */}
                <div className="pt-2 mt-1 border-t border-white/5 flex items-center justify-between text-[11px] text-zinc-400">
                  <span>🍬 {prog.modakasCollected}/3</span>
                  {prog.highScore > 0 && (
                    <span className="font-mono text-amber-300">
                      ⭐ {prog.highScore}
                    </span>
                  )}
                </div>

                {/* Play hover prompt */}
                {!isLocked && (
                  <div className="mt-2.5 w-full py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500 text-amber-300 hover:text-black font-extrabold text-xs flex items-center justify-center gap-1 transition-colors">
                    <Play size={11} className="fill-current" />
                    <span>Play</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Footer Summary */}
        <div className="pt-3 border-t border-amber-500/20 flex flex-col sm:flex-row items-center justify-between text-xs text-zinc-400 gap-2">
          <div className="flex items-center gap-4">
            <span>Total Stars: <strong className="text-amber-300">{totalStars}/{maxPossibleStars}</strong></span>
            <span>Completed: <strong className="text-emerald-400">{progress.filter(p => p.completed).length}/10</strong></span>
          </div>
          <div className="text-amber-200/80 italic text-center sm:text-right">
            Defeat the final boss in Level 10 to celebrate the Festival Victory!
          </div>
        </div>
      </div>
    </div>
  );
};
