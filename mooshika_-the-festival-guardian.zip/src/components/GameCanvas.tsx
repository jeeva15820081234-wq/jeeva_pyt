/**
 * Mooshika: The Festival Guardian - Game Canvas Container
 */

import React, { useEffect, useRef, useCallback } from 'react';
import { GameEngine, InputState } from '../game/engine';
import { GameRenderer } from '../game/renderer';
import { CANVAS_WIDTH, CANVAS_HEIGHT } from '../game/constants';

interface GameCanvasProps {
  engine: GameEngine;
  isPaused: boolean;
  onPauseToggle: () => void;
  inputRef?: React.MutableRefObject<InputState>;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  engine,
  isPaused,
  onPauseToggle,
  inputRef: externalInputRef,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const rendererRef = useRef<GameRenderer | null>(null);
  const animFrameIdRef = useRef<number | null>(null);

  // Input state referenced directly in requestAnimationFrame loop
  const internalInputRef = useRef<InputState>({
    left: false,
    right: false,
    up: false,
    down: false,
    jump: false,
    dash: false,
    special: false,
  });
  const inputRef = externalInputRef || internalInputRef;

  // Keyboard Event Handlers
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    // Prevent default scrolling for game keys
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
      e.preventDefault();
    }

    if (e.code === 'Escape' || e.code === 'KeyP') {
      onPauseToggle();
      return;
    }

    const input = inputRef.current;
    switch (e.code) {
      case 'ArrowLeft':
      case 'KeyA':
        input.left = true;
        break;
      case 'ArrowRight':
      case 'KeyD':
        input.right = true;
        break;
      case 'ArrowUp':
      case 'KeyW':
        input.up = true;
        break;
      case 'ArrowDown':
      case 'KeyS':
        input.down = true;
        break;
      case 'Space':
        input.jump = true;
        break;
      case 'ShiftLeft':
      case 'ShiftRight':
      case 'KeyJ':
        input.dash = true;
        break;
      case 'KeyE':
      case 'KeyK':
        input.special = true;
        break;
    }
  }, [onPauseToggle]);

  const handleKeyUp = useCallback((e: KeyboardEvent) => {
    const input = inputRef.current;
    switch (e.code) {
      case 'ArrowLeft':
      case 'KeyA':
        input.left = false;
        break;
      case 'ArrowRight':
      case 'KeyD':
        input.right = false;
        break;
      case 'ArrowUp':
      case 'KeyW':
        input.up = false;
        break;
      case 'ArrowDown':
      case 'KeyS':
        input.down = false;
        break;
      case 'Space':
        input.jump = false;
        break;
      case 'ShiftLeft':
      case 'ShiftRight':
      case 'KeyJ':
        input.dash = false;
        break;
      case 'KeyE':
      case 'KeyK':
        input.special = false;
        break;
    }
  }, []);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [handleKeyDown, handleKeyUp]);

  // Main Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;

    rendererRef.current = new GameRenderer(ctx);

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = CANVAS_WIDTH * dpr;
    canvas.height = CANVAS_HEIGHT * dpr;
    ctx.scale(dpr, dpr);

    let lastTime = performance.now();

    const loop = (currentTime: number) => {
      animFrameIdRef.current = requestAnimationFrame(loop);

      const delta = currentTime - lastTime;
      // Cap max delta to prevent tunneling if tab was inactive
      if (delta > 100) {
        lastTime = currentTime;
      }

      if (!isPaused && engine) {
        engine.update(inputRef.current);
      }

      if (rendererRef.current && engine) {
        rendererRef.current.render(
          engine.level,
          engine.cameraX,
          engine.cameraY,
          engine.player,
          engine.particles,
          engine.floatingTexts,
          engine.projectiles,
          engine.screenShake
        );
      }

      lastTime = currentTime;
    };

    animFrameIdRef.current = requestAnimationFrame(loop);

    return () => {
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
    };
  }, [engine, isPaused]);

  return (
    <div
      ref={containerRef}
      id="game-canvas-container"
      className="relative w-full h-full flex items-center justify-center bg-black overflow-hidden select-none"
    >
      <canvas
        ref={canvasRef}
        id="game-canvas"
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'contain',
          maxWidth: '100vw',
          maxHeight: '100vh',
          imageRendering: 'auto',
        }}
      />
    </div>
  );
};
