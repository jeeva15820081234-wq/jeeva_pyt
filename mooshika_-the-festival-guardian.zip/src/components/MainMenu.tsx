/**
 * Mooshika: The Festival Guardian - Main Menu
 */

import React from 'react';
import { Play, BookOpen, Map, Trophy, Volume2, VolumeX, Sparkles, Gamepad2 } from 'lucide-react';

interface MainMenuProps {
  onStartGame: () => void;
  onOpenStory: () => void;
  onOpenLevelSelect: () => void;
  onOpenAchievements: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  showTouchControls?: boolean;
  onToggleTouchControls?: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  onStartGame,
  onOpenStory,
  onOpenLevelSelect,
  onOpenAchievements,
  isMuted,
  onToggleMute,
  showTouchControls,
  onToggleTouchControls,
}) => {
  return (
    <div id="main-menu" className="absolute inset-0 z-30 flex flex-col items-center justify-between p-4 sm:p-6 bg-gradient-to-b from-purple-950/90 via-[#180b2a]/95 to-[#0b0614] backdrop-blur-sm select-none overflow-y-auto">
      {/* Top Header: Sound Toggle & Touch Controls */}
      <div className="w-full max-w-4xl flex justify-between items-center gap-2">
        <div className="flex items-center gap-1.5 sm:gap-2 bg-amber-500/10 border border-amber-500/20 px-2.5 sm:px-3 py-1 rounded-full text-[11px] sm:text-xs font-semibold text-amber-300">
          <Sparkles size={14} />
          <span>Vinayagar Chavurthi</span>
        </div>

        <div className="flex items-center gap-2">
          {onToggleTouchControls && (
            <button
              type="button"
              id="menu-touch-controls-toggle"
              onClick={onToggleTouchControls}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border transition-all text-xs font-medium cursor-pointer ${
                showTouchControls
                  ? 'bg-amber-500/25 text-amber-300 border-amber-500/50 shadow-[0_0_12px_rgba(245,158,11,0.3)]'
                  : 'bg-black/40 hover:bg-black/60 text-zinc-400 border-zinc-700'
              }`}
            >
              <Gamepad2 size={15} />
              <span className="hidden xs:inline">Touch Controls:</span>
              <span>{showTouchControls ? 'ON' : 'OFF'}</span>
            </button>
          )}

          <button
            type="button"
            id="menu-sound-toggle"
            onClick={onToggleMute}
            className="flex items-center gap-1.5 bg-black/40 hover:bg-black/60 text-amber-300 px-3 py-1.5 rounded-full border border-amber-500/30 transition-all text-xs font-medium cursor-pointer"
          >
            {isMuted ? <VolumeX size={15} /> : <Volume2 size={15} />}
            <span>{isMuted ? 'Muted' : 'Sound'}</span>
          </button>
        </div>
      </div>

      {/* Hero Branding */}
      <div className="flex flex-col items-center text-center my-auto py-6">
        {/* Animated Cute Mooshika Icon presentation */}
        <div className="relative mb-4">
          <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-gradient-to-tr from-amber-600 via-orange-500 to-yellow-300 p-1 shadow-[0_0_35px_rgba(245,158,11,0.5)] flex items-center justify-center animate-pulse">
            <div className="w-full h-full rounded-full bg-[#1e1035] flex items-center justify-center text-5xl sm:text-6xl">
              🐭
            </div>
          </div>
          {/* Floating Modaka & Diya badges */}
          <div className="absolute -top-2 -right-2 text-2xl animate-bounce">
            🍬
          </div>
          <div className="absolute -bottom-1 -left-2 text-2xl animate-bounce" style={{ animationDelay: '0.4s' }}>
            🪔
          </div>
        </div>

        {/* Title */}
        <h1 className="text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tight font-festive bg-gradient-to-r from-yellow-300 via-amber-400 to-orange-500 bg-clip-text text-transparent drop-shadow-[0_4px_12px_rgba(245,158,11,0.4)]">
          MOOSHIKA
        </h1>
        <p className="text-lg sm:text-2xl font-bold tracking-widest text-amber-200 mt-1 uppercase font-festive">
          The Festival Guardian
        </p>
        <p className="text-sm text-zinc-300 max-w-md mt-2 leading-relaxed">
          The sacred Modakas have been scattered across the land! Help Mooshika recover them before the celebration of Vinayagar Chavurthi begins.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 mt-8 w-full max-w-sm sm:max-w-md justify-center">
          <button
            id="btn-play-game"
            onClick={onStartGame}
            className="flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-500 text-black font-extrabold text-base sm:text-lg shadow-[0_0_25px_rgba(245,158,11,0.5)] hover:scale-105 active:scale-95 transition-all cursor-pointer"
          >
            <Play size={20} className="fill-black" />
            <span>Play Game</span>
          </button>

          <button
            id="btn-level-select"
            onClick={onOpenLevelSelect}
            className="flex items-center justify-center gap-2 px-5 py-3.5 rounded-2xl bg-black/50 hover:bg-black/70 border-2 border-amber-500/40 text-amber-200 font-bold text-sm sm:text-base hover:border-amber-400 active:scale-95 transition-all cursor-pointer"
          >
            <Map size={18} />
            <span>Select Level</span>
          </button>
        </div>

        {/* Secondary Buttons: Story & Achievements */}
        <div className="flex items-center gap-3 mt-4">
          <button
            id="btn-story"
            onClick={onOpenStory}
            className="flex items-center gap-1.5 text-xs text-amber-300/80 hover:text-amber-200 bg-amber-500/10 hover:bg-amber-500/20 px-3.5 py-1.5 rounded-full border border-amber-500/20 transition-all cursor-pointer"
          >
            <BookOpen size={13} />
            <span>Story & Lore</span>
          </button>

          <button
            id="btn-achievements"
            onClick={onOpenAchievements}
            className="flex items-center gap-1.5 text-xs text-amber-300/80 hover:text-amber-200 bg-amber-500/10 hover:bg-amber-500/20 px-3.5 py-1.5 rounded-full border border-amber-500/20 transition-all cursor-pointer"
          >
            <Trophy size={13} />
            <span>Achievements</span>
          </button>
        </div>
      </div>

      {/* Desktop / Mobile Controls Hint */}
      <div className="w-full max-w-md bg-black/40 border border-amber-500/20 rounded-2xl p-2.5 text-center text-[11px] text-zinc-400">
        <span className="font-semibold text-amber-300">PC:</span> WASD / Arrows to Move • SPACE to Jump • SHIFT to Dash • E for Bell Blast • ESC to Pause
        <br />
        <span className="font-semibold text-amber-300">Mobile:</span> On-screen touch buttons
      </div>
    </div>
  );
};
