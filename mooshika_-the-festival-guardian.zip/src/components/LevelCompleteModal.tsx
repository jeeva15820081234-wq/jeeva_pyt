/**
 * Mooshika: The Festival Guardian - Level Complete Modal
 */

import React, { useEffect } from 'react';
import { Star, ArrowRight, RotateCcw, Map } from 'lucide-react';
import confetti from 'canvas-confetti';

interface LevelCompleteModalProps {
  levelNumber: number;
  levelTitle: string;
  stars: number;
  score: number;
  modakasFound: number;
  totalModakas: number;
  hasNextLevel: boolean;
  onNextLevel: () => void;
  onReplay: () => void;
  onLevelSelect: () => void;
}

export const LevelCompleteModal: React.FC<LevelCompleteModalProps> = ({
  levelNumber,
  levelTitle,
  stars,
  score,
  modakasFound,
  totalModakas,
  hasNextLevel,
  onNextLevel,
  onReplay,
  onLevelSelect,
}) => {
  useEffect(() => {
    // Launch festive flower / golden confetti celebration
    try {
      confetti({
        particleCount: 75,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#f59e0b', '#f97316', '#fbbf24', '#ec4899', '#facc15'],
      });
    } catch {
      // Fallback
    }
  }, []);

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md select-none">
      <div className="w-full max-w-md bg-gradient-to-b from-[#2a134a] to-[#120722] border-2 border-amber-500/50 rounded-3xl p-6 sm:p-8 shadow-[0_0_50px_rgba(245,158,11,0.35)] flex flex-col items-center text-center">
        {/* Festive Header Icon */}
        <div className="text-4xl mb-2 animate-bounce">
          🪔
        </div>

        <h2 className="text-3xl sm:text-4xl font-extrabold text-amber-300 font-festive drop-shadow-[0_2px_10px_rgba(245,158,11,0.4)]">
          Level Cleared!
        </h2>
        <p className="text-sm font-semibold text-amber-200/80 mb-5">
          Level {levelNumber}: {levelTitle}
        </p>

        {/* Stars Display (1 to 3) */}
        <div className="flex items-center justify-center gap-3 my-2">
          {[1, 2, 3].map(s => (
            <div
              key={s}
              className={`p-2 rounded-2xl border transition-all duration-300 transform ${
                s <= stars
                  ? 'bg-amber-500/20 border-amber-400 text-amber-400 scale-110 shadow-[0_0_15px_rgba(251,191,36,0.6)]'
                  : 'bg-zinc-900 border-zinc-800 text-zinc-700 scale-90'
              }`}
            >
              <Star
                size={34}
                className={s <= stars ? 'fill-amber-400 animate-pulse' : 'fill-zinc-800'}
              />
            </div>
          ))}
        </div>

        {/* Rewards & Score Summary */}
        <div className="w-full bg-black/40 border border-amber-500/20 rounded-2xl p-4 my-5 flex justify-around text-center">
          <div>
            <div className="text-xs text-zinc-400 font-medium">Sacred Modakas</div>
            <div className="text-lg font-extrabold text-amber-300 flex items-center justify-center gap-1 mt-0.5">
              <span>🍬</span>
              <span>{modakasFound}/{totalModakas}</span>
            </div>
          </div>

          <div className="w-px bg-white/10" />

          <div>
            <div className="text-xs text-zinc-400 font-medium">Level Score</div>
            <div className="text-lg font-extrabold text-white font-mono mt-0.5">
              ⭐ {score.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5 w-full">
          {hasNextLevel ? (
            <button
              onClick={onNextLevel}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-500 text-black font-extrabold text-base flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(245,158,11,0.4)] active:scale-95 transition-all cursor-pointer"
            >
              <span>Next Level</span>
              <ArrowRight size={18} />
            </button>
          ) : (
            <button
              onClick={onLevelSelect}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-500 text-black font-extrabold text-base flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(245,158,11,0.4)] active:scale-95 transition-all cursor-pointer"
            >
              <span>View Festival Celebration</span>
              <ArrowRight size={18} />
            </button>
          )}

          <div className="flex gap-2 w-full mt-1">
            <button
              onClick={onReplay}
              className="flex-1 py-2.5 rounded-2xl bg-white/5 hover:bg-white/10 text-zinc-300 hover:text-white font-semibold text-xs flex items-center justify-center gap-1.5 border border-white/10 active:scale-95 transition-all cursor-pointer"
            >
              <RotateCcw size={14} />
              <span>Replay</span>
            </button>

            <button
              onClick={onLevelSelect}
              className="flex-1 py-2.5 rounded-2xl bg-white/5 hover:bg-white/10 text-zinc-300 hover:text-white font-semibold text-xs flex items-center justify-center gap-1.5 border border-white/10 active:scale-95 transition-all cursor-pointer"
            >
              <Map size={14} />
              <span>Level Map</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
