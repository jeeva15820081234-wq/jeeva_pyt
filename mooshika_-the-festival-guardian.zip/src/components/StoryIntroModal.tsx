/**
 * Mooshika: The Festival Guardian - Story Intro Modal
 */

import React, { useState } from 'react';
import { ArrowRight, ArrowLeft, Play, X } from 'lucide-react';

interface StoryIntroModalProps {
  onStartGame: () => void;
  onClose: () => void;
}

const STORY_SLIDES = [
  {
    icon: '🪔',
    title: 'The Great Festival',
    text: 'The sacred festival of Vinayagar Chavurthi (Ganesh Chaturthi) is about to dawn across the land. Devotees have decorated the village with fragrant marigold torans, rangolis, and brass diyas to welcome Lord Vinayagar.',
  },
  {
    icon: '🍬',
    title: 'The Stolen Modakas',
    text: 'A grand plate of divine, freshly steamed Festival Modakas was prepared for the holy altar. But just before the ritual, mischievous shadow creatures crept into the shrine and scattered the sweets far and wide!',
  },
  {
    icon: '🐭',
    title: 'Mooshika Steps Forward',
    text: 'Mooshika, the brave and faithful companion of Lord Vinayagar, vows to recover every sacred Modaka. Through bustling markets, ancient stone temple shafts, lotus groves, rivers, and high drum hills, the journey begins!',
  },
  {
    icon: '🏆',
    title: 'Your Divine Quest',
    text: 'Guide Mooshika across 10 distinct lands. Jump, dash, bounce on festival drums, ring sacred bells, and defeat "The Shadow of Chaos" to bring back the light!',
  },
];

export const StoryIntroModal: React.FC<StoryIntroModalProps> = ({ onStartGame, onClose }) => {
  const [slide, setSlide] = useState(0);

  const isLast = slide === STORY_SLIDES.length - 1;

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg bg-[#1a0f2e] border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-[0_0_40px_rgba(245,158,11,0.25)] flex flex-col justify-between min-h-[380px]">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-zinc-400 hover:text-white rounded-full bg-white/5 hover:bg-white/10 transition-all cursor-pointer"
        >
          <X size={18} />
        </button>

        {/* Slide Content */}
        <div className="flex flex-col items-center text-center my-auto py-2">
          <div className="text-6xl mb-4 animate-bounce">
            {STORY_SLIDES[slide].icon}
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-amber-300 font-festive mb-3">
            {STORY_SLIDES[slide].title}
          </h2>
          <p className="text-sm sm:text-base text-zinc-200 leading-relaxed max-w-md">
            {STORY_SLIDES[slide].text}
          </p>
        </div>

        {/* Navigation / Progress Indicator */}
        <div className="flex items-center justify-between pt-6 border-t border-amber-500/20 mt-4">
          {/* Dot Indicators */}
          <div className="flex items-center gap-1.5">
            {STORY_SLIDES.map((_, i) => (
              <div
                key={i}
                className={`h-2 rounded-full transition-all duration-300 ${
                  i === slide ? 'w-6 bg-amber-400' : 'w-2 bg-zinc-700'
                }`}
              />
            ))}
          </div>

          {/* Navigation Buttons */}
          <div className="flex items-center gap-2">
            {slide > 0 && (
              <button
                onClick={() => setSlide(s => s - 1)}
                className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-300 text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer"
              >
                <ArrowLeft size={14} />
                <span>Prev</span>
              </button>
            )}

            {isLast ? (
              <button
                onClick={onStartGame}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black text-xs font-extrabold flex items-center gap-1.5 shadow-md active:scale-95 transition-all cursor-pointer"
              >
                <Play size={14} className="fill-black" />
                <span>Begin Adventure</span>
              </button>
            ) : (
              <button
                onClick={() => setSlide(s => s + 1)}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-black text-xs font-bold flex items-center gap-1 transition-all cursor-pointer"
              >
                <span>Next</span>
                <ArrowRight size={14} />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
