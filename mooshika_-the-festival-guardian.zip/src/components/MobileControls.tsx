/**
 * Mooshika: The Festival Guardian - Ultra-Responsive Mobile Touch Controls
 * Features dual-zone touch handling, multi-touch support, haptic feedback,
 * sliding D-Pad input, and vibrant tactile buttons.
 */

import React, { useState, useRef, useCallback, useEffect } from 'react';
import { ArrowLeft, ArrowRight, ArrowUp, Zap, Bell } from 'lucide-react';
import { InputState } from '../game/engine';
import { sound } from '../game/sound';

interface MobileControlsProps {
  inputRef: React.MutableRefObject<InputState>;
}

export const MobileControls: React.FC<MobileControlsProps> = ({ inputRef }) => {
  const [activeLeft, setActiveLeft] = useState(false);
  const [activeRight, setActiveRight] = useState(false);
  const [activeJump, setActiveJump] = useState(false);
  const [activeDash, setActiveDash] = useState(false);
  const [activeSpecial, setActiveSpecial] = useState(false);

  const dpadZoneRef = useRef<HTMLDivElement | null>(null);
  const activeMovementTouchId = useRef<number | null>(null);

  // Trigger gentle haptic feedback on supported mobile devices
  const triggerHaptic = useCallback((duration = 12) => {
    try {
      if (typeof window !== 'undefined' && 'vibrate' in navigator) {
        navigator.vibrate(duration);
      }
    } catch {
      // Ignore
    }
  }, []);

  // Unlock web audio on touch
  const handleAnyTouch = useCallback(() => {
    sound.unlockAudio();
  }, []);

  // Update input and state for individual action buttons
  const setActionKey = useCallback((key: 'jump' | 'dash' | 'special', active: boolean) => {
    handleAnyTouch();
    if (active) triggerHaptic(15);
    inputRef.current[key] = active;

    if (key === 'jump') setActiveJump(active);
    if (key === 'dash') setActiveDash(active);
    if (key === 'special') setActiveSpecial(active);
  }, [handleAnyTouch, triggerHaptic, inputRef]);

  // Set directional horizontal movement
  const setDirection = useCallback((dir: 'left' | 'right' | 'none') => {
    handleAnyTouch();
    if (dir === 'left') {
      inputRef.current.left = true;
      inputRef.current.right = false;
      setActiveLeft(true);
      setActiveRight(false);
    } else if (dir === 'right') {
      inputRef.current.left = false;
      inputRef.current.right = true;
      setActiveLeft(false);
      setActiveRight(true);
    } else {
      inputRef.current.left = false;
      inputRef.current.right = false;
      setActiveLeft(false);
      setActiveRight(false);
    }
  }, [handleAnyTouch, inputRef]);

  // Handle touch drag across directional movement pad
  const updateMovementFromTouch = useCallback((touchX: number) => {
    if (!dpadZoneRef.current) return;
    const rect = dpadZoneRef.current.getBoundingClientRect();
    const midX = rect.left + rect.width / 2;

    if (touchX < midX - 8) {
      setDirection('left');
    } else if (touchX > midX + 8) {
      setDirection('right');
    } else {
      setDirection('none');
    }
  }, [setDirection]);

  // Touch handlers for D-Pad zone
  const handleDpadTouchStart = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    handleAnyTouch();
    triggerHaptic(10);
    const touch = e.changedTouches[0];
    if (!touch) return;
    activeMovementTouchId.current = touch.identifier;
    updateMovementFromTouch(touch.clientX);
  }, [handleAnyTouch, triggerHaptic, updateMovementFromTouch]);

  const handleDpadTouchMove = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    if (activeMovementTouchId.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === activeMovementTouchId.current) {
        updateMovementFromTouch(touch.clientX);
        break;
      }
    }
  }, [updateMovementFromTouch]);

  const handleDpadTouchEnd = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    if (activeMovementTouchId.current === null) return;
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === activeMovementTouchId.current) {
        activeMovementTouchId.current = null;
        setDirection('none');
        break;
      }
    }
  }, [setDirection]);

  // Cleanup on unmount or blur
  useEffect(() => {
    const handleGlobalRelease = () => {
      inputRef.current.left = false;
      inputRef.current.right = false;
      inputRef.current.jump = false;
      inputRef.current.dash = false;
      inputRef.current.special = false;
      setActiveLeft(false);
      setActiveRight(false);
      setActiveJump(false);
      setActiveDash(false);
      setActiveSpecial(false);
      activeMovementTouchId.current = null;
    };

    window.addEventListener('touchend', handleGlobalRelease, { passive: true });
    window.addEventListener('touchcancel', handleGlobalRelease, { passive: true });
    window.addEventListener('mouseup', handleGlobalRelease);

    return () => {
      window.removeEventListener('touchend', handleGlobalRelease);
      window.removeEventListener('touchcancel', handleGlobalRelease);
      window.removeEventListener('mouseup', handleGlobalRelease);
    };
  }, [inputRef]);

  return (
    <div
      id="mobile-controls-overlay"
      className="fixed inset-0 pointer-events-none flex justify-between items-end px-3 sm:px-6 pb-4 sm:pb-6 select-none touch-none z-40"
      style={{ paddingBottom: 'max(1rem, env(safe-area-inset-bottom, 1rem))' }}
    >
      {/* ============================================================ */}
      {/* LEFT SIDE: Directional Movement Pad (Left & Right)          */}
      {/* ============================================================ */}
      <div
        ref={dpadZoneRef}
        id="dpad-movement-zone"
        className="pointer-events-auto flex items-center bg-black/50 backdrop-blur-md p-1.5 rounded-3xl border border-amber-500/30 shadow-2xl"
        onTouchStart={handleDpadTouchStart}
        onTouchMove={handleDpadTouchMove}
        onTouchEnd={handleDpadTouchEnd}
        onTouchCancel={handleDpadTouchEnd}
      >
        {/* Left Direction Button */}
        <button
          type="button"
          id="btn-touch-left"
          onMouseDown={() => { triggerHaptic(10); setDirection('left'); }}
          onMouseUp={() => setDirection('none')}
          className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex flex-col items-center justify-center transition-all ${
            activeLeft
              ? 'bg-amber-500 text-black scale-95 shadow-[0_0_20px_rgba(245,158,11,0.8)]'
              : 'bg-zinc-900/80 hover:bg-zinc-800 text-amber-300 border border-amber-500/20'
          }`}
          aria-label="Move Left"
        >
          <ArrowLeft size={28} strokeWidth={3} />
          <span className="text-[9px] font-black tracking-tighter uppercase mt-0.5 opacity-80">Left</span>
        </button>

        {/* Center Divider / Touch Indicator */}
        <div className="w-1.5 h-8 bg-amber-500/20 mx-1 rounded-full" />

        {/* Right Direction Button */}
        <button
          type="button"
          id="btn-touch-right"
          onMouseDown={() => { triggerHaptic(10); setDirection('right'); }}
          onMouseUp={() => setDirection('none')}
          className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex flex-col items-center justify-center transition-all ${
            activeRight
              ? 'bg-amber-500 text-black scale-95 shadow-[0_0_20px_rgba(245,158,11,0.8)]'
              : 'bg-zinc-900/80 hover:bg-zinc-800 text-amber-300 border border-amber-500/20'
          }`}
          aria-label="Move Right"
        >
          <ArrowRight size={28} strokeWidth={3} />
          <span className="text-[9px] font-black tracking-tighter uppercase mt-0.5 opacity-80">Right</span>
        </button>
      </div>

      {/* ============================================================ */}
      {/* RIGHT SIDE: Action Buttons (Bell Blast, Dash, Jump)         */}
      {/* ============================================================ */}
      <div className="pointer-events-auto flex items-end gap-2.5 sm:gap-3.5">
        {/* Sacred Bell / Special Attack Button */}
        <div className="flex flex-col items-center">
          <button
            type="button"
            id="btn-touch-special"
            onTouchStart={e => { e.preventDefault(); setActionKey('special', true); }}
            onTouchEnd={e => { e.preventDefault(); setActionKey('special', false); }}
            onTouchCancel={e => { e.preventDefault(); setActionKey('special', false); }}
            onMouseDown={() => setActionKey('special', true)}
            onMouseUp={() => setActionKey('special', false)}
            className={`w-13 h-13 sm:w-15 sm:h-15 rounded-2xl flex flex-col items-center justify-center transition-all border ${
              activeSpecial
                ? 'bg-yellow-400 text-black scale-90 shadow-[0_0_22px_rgba(250,204,21,0.9)] border-yellow-300'
                : 'bg-black/60 backdrop-blur-md text-yellow-300 border-yellow-500/30 active:scale-95 shadow-lg'
            }`}
            title="Bell Purification (25 Energy)"
            aria-label="Bell Blast"
          >
            <Bell size={22} className={activeSpecial ? 'animate-bounce' : ''} />
            <span className="text-[9px] font-extrabold tracking-tight mt-0.5">BELL</span>
          </button>
          <span className="text-[9px] font-bold text-yellow-400 mt-1 bg-black/60 px-1.5 py-0.2 rounded-full border border-yellow-500/20">
            25⚡
          </span>
        </div>

        {/* Dash Button */}
        <div className="flex flex-col items-center">
          <button
            type="button"
            id="btn-touch-dash"
            onTouchStart={e => { e.preventDefault(); setActionKey('dash', true); }}
            onTouchEnd={e => { e.preventDefault(); setActionKey('dash', false); }}
            onTouchCancel={e => { e.preventDefault(); setActionKey('dash', false); }}
            onMouseDown={() => setActionKey('dash', true)}
            onMouseUp={() => setActionKey('dash', false)}
            className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex flex-col items-center justify-center transition-all border ${
              activeDash
                ? 'bg-orange-500 text-black scale-90 shadow-[0_0_22px_rgba(249,115,22,0.9)] border-orange-400'
                : 'bg-black/60 backdrop-blur-md text-orange-300 border-orange-500/40 active:scale-95 shadow-lg'
            }`}
            title="Dash Glide"
            aria-label="Dash"
          >
            <Zap size={24} strokeWidth={2.5} />
            <span className="text-[9px] font-extrabold tracking-tight mt-0.5">DASH</span>
          </button>
          <span className="text-[9px] font-bold text-orange-300/80 mt-1">
            Glide
          </span>
        </div>

        {/* Jump Button (Largest, most prominent, double jump ready) */}
        <div className="flex flex-col items-center">
          <button
            type="button"
            id="btn-touch-jump"
            onTouchStart={e => { e.preventDefault(); setActionKey('jump', true); }}
            onTouchEnd={e => { e.preventDefault(); setActionKey('jump', false); }}
            onTouchCancel={e => { e.preventDefault(); setActionKey('jump', false); }}
            onMouseDown={() => setActionKey('jump', true)}
            onMouseUp={() => setActionKey('jump', false)}
            className={`w-18 h-18 sm:w-20 sm:h-20 rounded-3xl flex flex-col items-center justify-center transition-all ${
              activeJump
                ? 'bg-amber-400 text-black scale-90 shadow-[0_0_30px_rgba(251,191,36,1)]'
                : 'bg-gradient-to-tr from-amber-600 via-amber-500 to-yellow-400 text-black shadow-[0_0_20px_rgba(245,158,11,0.6)] active:scale-95'
            }`}
            title="Jump & Double Jump"
            aria-label="Jump / Double Jump"
          >
            <ArrowUp size={36} strokeWidth={3.5} />
            <span className="text-[11px] font-black tracking-wider uppercase -mt-0.5">JUMP</span>
          </button>
          <span className="text-[9px] font-bold text-amber-300/90 mt-1">
            2× Jump
          </span>
        </div>
      </div>
    </div>
  );
};
