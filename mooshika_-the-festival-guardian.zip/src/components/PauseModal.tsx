/**
 * Mooshika: The Festival Guardian - Pause Modal
 */

import React from 'react';
import { Play, RotateCcw, Map, Home, Volume2, VolumeX, Gamepad2 } from 'lucide-react';

interface PauseModalProps {
  onResume: () => void;
  onRestart: () => void;
  onLevelSelect: () => void;
  onMainMenu: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  levelTitle: string;
  showTouchControls?: boolean;
  onToggleTouchControls?: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  onResume,
  onRestart,
  onLevelSelect,
  onMainMenu,
  isMuted,
  onToggleMute,
  levelTitle,
  showTouchControls,
  onToggleTouchControls,
}) => {
  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md select-none">
      <div className="w-full max-w-sm bg-[#1a0f2e] border-2 border-amber-500/40 rounded-3xl p-6 shadow-[0_0_40px_rgba(245,158,11,0.3)] flex flex-col items-center text-center">
        <h2 className="text-3xl font-extrabold text-amber-300 font-festive mb-1">
          Game Paused
        </h2>
        <p className="text-xs text-amber-200/70 mb-6">
          {levelTitle}
        </p>

        {/* Menu Buttons */}
        <div className="flex flex-col gap-2.5 w-full">
          {/* Resume */}
          <button
            type="button"
            onClick={onResume}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 text-black font-extrabold text-base flex items-center justify-center gap-2 hover:from-amber-400 hover:to-orange-400 active:scale-95 transition-all cursor-pointer shadow-md"
          >
            <Play size={18} className="fill-black" />
            <span>Resume</span>
          </button>

          {/* Touch Controls Toggle */}
          {onToggleTouchControls && (
            <button
              type="button"
              onClick={onToggleTouchControls}
              className={`w-full py-2.5 rounded-2xl font-semibold text-sm flex items-center justify-center gap-2 border active:scale-95 transition-all cursor-pointer ${
                showTouchControls
                  ? 'bg-amber-500/20 text-amber-200 border-amber-500/50'
                  : 'bg-white/5 hover:bg-white/10 text-zinc-300 border-white/10'
              }`}
            >
              <Gamepad2 size={16} />
              <span>Touch Controls: {showTouchControls ? 'ON' : 'OFF'}</span>
            </button>
          )}

          {/* Restart Level */}
          <button
            type="button"
            onClick={onRestart}
            className="w-full py-2.5 rounded-2xl bg-white/5 hover:bg-white/10 text-white font-semibold text-sm flex items-center justify-center gap-2 border border-white/10 active:scale-95 transition-all cursor-pointer"
          >
            <RotateCcw size={16} />
            <span>Restart Level</span>
          </button>

          {/* Level Select */}
          <button
            type="button"
            onClick={onLevelSelect}
            className="w-full py-2.5 rounded-2xl bg-white/5 hover:bg-white/10 text-white font-semibold text-sm flex items-center justify-center gap-2 border border-white/10 active:scale-95 transition-all cursor-pointer"
          >
            <Map size={16} />
            <span>Level Select</span>
          </button>

          {/* Sound Toggle */}
          <button
            type="button"
            onClick={onToggleMute}
            className="w-full py-2.5 rounded-2xl bg-white/5 hover:bg-white/10 text-amber-300 font-semibold text-sm flex items-center justify-center gap-2 border border-white/10 active:scale-95 transition-all cursor-pointer"
          >
            {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
            <span>{isMuted ? 'Unmute Sound' : 'Mute Sound'}</span>
          </button>

          {/* Main Menu */}
          <button
            type="button"
            onClick={onMainMenu}
            className="w-full py-2.5 rounded-2xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white font-medium text-xs flex items-center justify-center gap-2 transition-all cursor-pointer mt-1"
          >
            <Home size={14} />
            <span>Back to Main Menu</span>
          </button>
        </div>
      </div>
    </div>
  );
};
