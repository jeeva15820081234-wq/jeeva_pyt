/**
 * Mooshika: The Festival Guardian - Grand Victory Screen
 */

import React, { useEffect } from 'react';
import { PlayerStats, LevelProgress, Achievement } from '../game/types';
import { Trophy, Star, Sparkles, RotateCcw, Home } from 'lucide-react';
import confetti from 'canvas-confetti';

interface VictoryModalProps {
  stats: PlayerStats;
  progress: LevelProgress[];
  achievements: Achievement[];
  onPlayAgain: () => void;
  onMainMenu: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  stats,
  progress,
  achievements,
  onPlayAgain,
  onMainMenu,
}) => {
  const totalStars = progress.reduce((acc, p) => acc + p.stars, 0);
  const maxPossibleStars = 30;
  const unlockedAchievementsCount = achievements.filter(a => a.unlocked).length;
  const completionPercentage = Math.min(100, Math.round((totalStars / maxPossibleStars) * 100));

  useEffect(() => {
    // Grand fireworks / multi-stage celebratory confetti
    const duration = 3.5 * 1000;
    const end = Date.now() + duration;

    const interval = window.setInterval(() => {
      if (Date.now() > end) {
        clearInterval(interval);
        return;
      }

      confetti({
        startVelocity: 30,
        spread: 360,
        ticks: 60,
        origin: { x: Math.random(), y: Math.random() - 0.2 },
        colors: ['#f59e0b', '#f97316', '#fbbf24', '#ec4899', '#facc15', '#10b981'],
      });
    }, 350);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-gradient-to-b from-[#1c082e]/95 via-[#130620]/98 to-[#090212] backdrop-blur-lg select-none overflow-y-auto">
      <div className="relative w-full max-w-xl bg-gradient-to-b from-[#2d1252] to-[#120722] border-3 border-amber-400 rounded-3xl p-6 sm:p-8 shadow-[0_0_60px_rgba(245,158,11,0.5)] flex flex-col items-center text-center my-auto">
        {/* Divine Glowing Celebration Altar */}
        <div className="relative mb-3">
          <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-gradient-to-tr from-amber-500 via-orange-500 to-yellow-300 p-1 shadow-[0_0_40px_rgba(245,158,11,0.6)] flex items-center justify-center animate-bounce">
            <div className="w-full h-full rounded-full bg-[#1e0f35] flex items-center justify-center text-5xl">
              🪔
            </div>
          </div>
          <span className="absolute -top-1 -right-1 text-2xl">✨</span>
          <span className="absolute -bottom-1 -left-1 text-2xl">🍬</span>
        </div>

        {/* Title */}
        <h1 className="text-3xl sm:text-5xl font-extrabold text-amber-300 font-festive drop-shadow-[0_2px_12px_rgba(245,158,11,0.5)] uppercase tracking-wide">
          FESTIVAL SAVED!
        </h1>
        <h2 className="text-lg sm:text-xl font-bold tracking-widest text-amber-200 mt-1 uppercase font-festive">
          MOOSHIKA — THE TINY GUARDIAN
        </h2>

        {/* Narrative conclusion */}
        <p className="text-xs sm:text-sm text-zinc-300 max-w-md mt-2 leading-relaxed">
          The Shadow of Chaos has been purified! Mooshika placed all sacred Modakas upon Lord Vinayagar’s altar. The temple lamps blaze with warm golden light as joyful music and celebration fill every corner of the village!
        </p>

        {/* Grand Stats Breakdown Grid */}
        <div className="w-full grid grid-cols-2 sm:grid-cols-3 gap-2.5 my-6">
          {/* Final Score */}
          <div className="bg-black/40 border border-amber-500/30 rounded-2xl p-3 flex flex-col items-center">
            <span className="text-xs text-zinc-400 font-medium">Final Score</span>
            <span className="text-base sm:text-lg font-extrabold text-white font-mono mt-0.5">
              ⭐ {stats.score.toLocaleString()}
            </span>
          </div>

          {/* Stars */}
          <div className="bg-black/40 border border-amber-500/30 rounded-2xl p-3 flex flex-col items-center">
            <span className="text-xs text-zinc-400 font-medium">Total Stars</span>
            <span className="text-base sm:text-lg font-extrabold text-amber-300 font-mono mt-0.5 flex items-center gap-1">
              <Star size={16} className="fill-amber-400 text-amber-400" />
              {totalStars}/{maxPossibleStars}
            </span>
          </div>

          {/* Modakas Recovered */}
          <div className="bg-black/40 border border-amber-500/30 rounded-2xl p-3 flex flex-col items-center">
            <span className="text-xs text-zinc-400 font-medium">Modakas Found</span>
            <span className="text-base sm:text-lg font-extrabold text-amber-300 font-mono mt-0.5">
              🍬 {stats.totalModakas}
            </span>
          </div>

          {/* Festival Bells */}
          <div className="bg-black/40 border border-amber-500/30 rounded-2xl p-3 flex flex-col items-center">
            <span className="text-xs text-zinc-400 font-medium">Bells Rung</span>
            <span className="text-base sm:text-lg font-extrabold text-amber-300 font-mono mt-0.5">
              🔔 {stats.totalBells}
            </span>
          </div>

          {/* Achievements */}
          <div className="bg-black/40 border border-amber-500/30 rounded-2xl p-3 flex flex-col items-center">
            <span className="text-xs text-zinc-400 font-medium">Achievements</span>
            <span className="text-base sm:text-lg font-extrabold text-amber-300 font-mono mt-0.5 flex items-center gap-1">
              <Trophy size={15} className="text-amber-400" />
              {unlockedAchievementsCount}/{achievements.length}
            </span>
          </div>

          {/* Completion % */}
          <div className="bg-black/40 border border-amber-500/30 rounded-2xl p-3 flex flex-col items-center">
            <span className="text-xs text-zinc-400 font-medium">Completion</span>
            <span className="text-base sm:text-lg font-extrabold text-emerald-400 font-mono mt-0.5">
              {completionPercentage}%
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 w-full max-w-md">
          <button
            onClick={onPlayAgain}
            className="flex-1 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-500 text-black font-extrabold text-base flex items-center justify-center gap-2 shadow-[0_0_25px_rgba(245,158,11,0.5)] active:scale-95 transition-all cursor-pointer"
          >
            <RotateCcw size={18} />
            <span>Play Again</span>
          </button>

          <button
            onClick={onMainMenu}
            className="sm:w-36 py-3.5 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-bold text-sm flex items-center justify-center gap-2 border border-white/10 active:scale-95 transition-all cursor-pointer"
          >
            <Home size={16} />
            <span>Menu</span>
          </button>
        </div>
      </div>
    </div>
  );
};
