/**
 * Mooshika: The Festival Guardian - Game Types & Interfaces
 */

export type GameState = 
  | 'menu'
  | 'story'
  | 'level_select'
  | 'playing'
  | 'paused'
  | 'level_complete'
  | 'game_over'
  | 'victory'
  | 'achievements';

export interface PlayerStats {
  score: number;
  highScore: number;
  coins: number;
  totalModakas: number;
  totalBells: number;
  lives: number;
  maxLives: number;
  health: number;
  maxHealth: number;
  festivalEnergy: number;
  maxFestivalEnergy: number;
  combo: number;
  comboTimer: number;
  maxCombo: number;
}

export type PowerUpType = 
  | 'modaka_power'   // Speed boost + trail
  | 'lotus_shield'   // Absorbs 1 hit
  | 'festival_dash'  // Infinite/enhanced dash
  | 'golden_bell'    // Freezes enemies
  | 'divine_light';  // Illuminates dark caves & reveals secret platforms

export interface ActivePowerUp {
  type: PowerUpType;
  duration: number; // remaining seconds
  maxDuration: number;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: number;
}

export interface LevelProgress {
  levelId: number;
  unlocked: boolean;
  completed: boolean;
  stars: number; // 0-3
  highScore: number;
  modakasCollected: number;
  totalModakas: number;
  bestTime: number; // in seconds
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  maxLife: number;
  life: number;
  shape?: 'circle' | 'petal' | 'star' | 'spark' | 'smoke' | 'note';
  rotation?: number;
  vRot?: number;
}

export interface FloatingText {
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
  vy: number;
  fontSize?: number;
}

export interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface Platform extends Rect {
  type: 'solid' | 'one_way' | 'moving' | 'crumbling' | 'drum' | 'boat' | 'hidden' | 'bouncy_lotus';
  color?: string;
  // Moving platform properties
  vx?: number;
  vy?: number;
  minX?: number;
  maxX?: number;
  minY?: number;
  maxY?: number;
  // Crumbling
  crumbleTimer?: number;
  isCrumbling?: boolean;
  respawnTimer?: number;
  // Hidden platforms (revealed by Divine Light or nearby lamps)
  revealed?: boolean;
  // Decorative
  theme?: string;
}

export interface Collectible extends Rect {
  id: string;
  type: 'coin' | 'modaka' | 'flower' | 'bell' | 'heart' | 'powerup' | 'secret';
  powerUpType?: PowerUpType;
  collected: boolean;
  bobOffset: number;
  value: number;
}

export interface Hazard extends Rect {
  type: 'spikes' | 'water' | 'falling_pot' | 'lightning' | 'shadow_fire';
  vy?: number;
  active?: boolean;
  initialY?: number;
}

export interface PuzzleSwitch extends Rect {
  id: string;
  targetPlatformId: string;
  isPressed: boolean;
  timer?: number;
}

export interface Lamp extends Rect {
  id: string;
  lit: boolean;
  radius: number;
}

export interface Enemy extends Rect {
  id: string;
  type: 'shadow_mouse' | 'shadow_crow' | 'shadow_imp' | 'stone_guardian' | 'river_shadow' | 'cloud_guardian' | 'shadow_beast' | 'mountain_guardian';
  vx: number;
  vy: number;
  facing: 1 | -1;
  minX?: number;
  maxX?: number;
  health: number;
  maxHealth: number;
  stunTimer: number;
  isDefeated: boolean;
  defeatTimer: number;
  animFrame: number;
  attackCooldown: number;
  isBoss?: boolean;
  bossName?: string;
  bossPhase?: number;
}

export interface BossAttack {
  type: 'shadow_bolt' | 'shockwave' | 'slam' | 'summon_minions';
  x: number;
  y: number;
  vx: number;
  vy: number;
  width: number;
  height: number;
  life: number;
  telegraphTimer?: number;
}

export interface LevelData {
  id: number;
  title: string;
  subtitle: string;
  storySnippet: string;
  objective: string;
  environment: 'village' | 'market' | 'temple' | 'forest' | 'river' | 'hills' | 'clouds' | 'cave' | 'mountain' | 'final';
  width: number;
  height: number;
  playerStart: { x: number; y: number };
  gate: Rect;
  platforms: Platform[];
  collectibles: Collectible[];
  hazards: Hazard[];
  switches?: PuzzleSwitch[];
  lamps?: Lamp[];
  enemies: Enemy[];
  boss?: {
    name: string;
    type: Enemy['type'];
    x: number;
    y: number;
    maxHealth: number;
  };
  specialMechanic?: string;
  timeLimit?: number; // optional target time in seconds
  ambientLighting?: number; // 0.0 (pitch dark except lamps) to 1.0 (bright daylight)
  wind?: { vx: number; vy: number };
}
