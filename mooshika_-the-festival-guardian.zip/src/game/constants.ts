/**
 * Mooshika: The Festival Guardian - Constants & Config
 */

import { Achievement } from './types';

// Internal virtual game canvas resolution (crisp 16:9 960x540 scaled to any viewport)
export const CANVAS_WIDTH = 960;
export const CANVAS_HEIGHT = 540;

export const PHYSICS = {
  GRAVITY: 0.58,
  MAX_FALL_SPEED: 13,
  RUN_SPEED: 4.8,
  RUN_ACCEL: 0.6,
  RUN_DECEL: 0.75,
  JUMP_FORCE: -11.6,
  DOUBLE_JUMP_FORCE: -10.2,
  WALL_SLIDE_SPEED: 2.2,
  WALL_JUMP_FORCE_X: 6.5,
  WALL_JUMP_FORCE_Y: -10.5,
  DASH_SPEED: 12.5,
  DASH_DURATION: 14, // frames (~0.23s)
  DASH_COOLDOWN: 36, // frames (~0.6s)
  INVULNERABILITY_FRAMES: 90, // 1.5s after taking damage
  DRUM_BOUNCE_FORCE: -17.5,
  BOUNCY_LOTUS_FORCE: -14.5,
  COMBO_TIMEOUT_FRAMES: 210, // ~3.5 seconds
};

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_modaka',
    title: 'First Modaka',
    description: 'Found your very first sacred Festival Modaka!',
    icon: '🍬',
    unlocked: false,
  },
  {
    id: 'bell_collector',
    title: 'Bell Collector',
    description: 'Ring 10 sacred Festival Bells across your journey.',
    icon: '🔔',
    unlocked: false,
  },
  {
    id: 'combo_master',
    title: 'Combo Master',
    description: 'Achieve a 5x score combo without taking damage.',
    icon: '⚡',
    unlocked: false,
  },
  {
    id: 'shadow_hunter',
    title: 'Shadow Hunter',
    description: 'Purify 25 shadow creatures with stuns or dashes.',
    icon: '✨',
    unlocked: false,
  },
  {
    id: 'perfect_level',
    title: 'Perfect Level',
    description: 'Complete any level collecting all 3 Modakas with 3 stars!',
    icon: '⭐',
    unlocked: false,
  },
  {
    id: 'secret_finder',
    title: 'Secret Finder',
    description: 'Discover a hidden path or secret festival relic.',
    icon: '🔍',
    unlocked: false,
  },
  {
    id: 'festival_guardian',
    title: 'Festival Guardian',
    description: 'Defeat The Shadow of Chaos and save Vinayagar Chavurthi!',
    icon: '🏆',
    unlocked: false,
  },
];

export const COLORS = {
  saffron: '#f97316',
  marigold: '#f59e0b',
  gold: '#fbbf24',
  deepGold: '#d97706',
  templeRed: '#dc2626',
  festivePink: '#ec4899',
  lotusGreen: '#10b981',
  darkBg: '#0f0b18',
  shadowPurple: '#4c1d95',
  skyBlue: '#0284c7',
  riverBlue: '#0ea5e9',
};
