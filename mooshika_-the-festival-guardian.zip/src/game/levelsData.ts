/**
 * Mooshika: The Festival Guardian - Handcrafted 10 Level Designs
 */

import { LevelData } from './types';

export const LEVELS: LevelData[] = [
  // ==========================================
  // LEVEL 1 — FESTIVAL VILLAGE (Tutorial Level)
  // ==========================================
  {
    id: 1,
    title: 'Festival Village',
    subtitle: 'Tutorial & Beginning of the Quest',
    storySnippet: 'Mischievous shadow creatures stole the sacred Modakas prepared for Lord Vinayagar! Mooshika must run and jump through the village streets to recover them.',
    objective: 'Collect 3 Modakas and reach the Festival Gate',
    environment: 'village',
    width: 2400,
    height: 600,
    playerStart: { x: 80, y: 440 },
    gate: { x: 2260, y: 400, width: 70, height: 110 },
    specialMechanic: 'Learn movement, jumping & stomping',
    ambientLighting: 1.0,
    platforms: [
      // Main Ground
      { x: 0, y: 510, width: 900, height: 90, type: 'solid' },
      // Low stepping roofs & platforms
      { x: 260, y: 420, width: 130, height: 24, type: 'one_way' },
      { x: 440, y: 350, width: 140, height: 24, type: 'one_way' },
      { x: 630, y: 280, width: 150, height: 24, type: 'one_way' },
      
      // Gap 1
      { x: 970, y: 510, width: 620, height: 90, type: 'solid' },
      // Village archways
      { x: 1040, y: 410, width: 120, height: 24, type: 'one_way' },
      { x: 1220, y: 330, width: 140, height: 24, type: 'one_way' },
      { x: 1420, y: 400, width: 130, height: 24, type: 'one_way' },

      // Boss Arena Ground
      { x: 1670, y: 510, width: 730, height: 90, type: 'solid' },
      // Platforms in boss area
      { x: 1780, y: 410, width: 110, height: 22, type: 'one_way' },
      { x: 2020, y: 410, width: 110, height: 22, type: 'one_way' },
    ],
    collectibles: [
      // Coins along the path
      { id: 'l1_c1', x: 280, y: 380, width: 20, height: 20, type: 'coin', collected: false, bobOffset: 0, value: 10 },
      { id: 'l1_c2', x: 340, y: 380, width: 20, height: 20, type: 'coin', collected: false, bobOffset: 1, value: 10 },
      { id: 'l1_c3', x: 460, y: 310, width: 20, height: 20, type: 'coin', collected: false, bobOffset: 2, value: 10 },
      { id: 'l1_f1', x: 520, y: 310, width: 22, height: 22, type: 'flower', collected: false, bobOffset: 3, value: 15 },
      
      // Sacred Modaka 1 (Above rooftops)
      { id: 'l1_m1', x: 700, y: 230, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 0, value: 100 },
      
      { id: 'l1_c4', x: 1080, y: 370, width: 20, height: 20, type: 'coin', collected: false, bobOffset: 1, value: 10 },
      { id: 'l1_f2', x: 1280, y: 290, width: 22, height: 22, type: 'flower', collected: false, bobOffset: 2, value: 15 },
      
      // Sacred Modaka 2 (Secret village toran)
      { id: 'l1_m2', x: 1290, y: 220, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 3, value: 100 },

      { id: 'l1_b1', x: 1470, y: 360, width: 26, height: 26, type: 'bell', collected: false, bobOffset: 0, value: 50 },

      // Sacred Modaka 3 (Guarded near gate)
      { id: 'l1_m3', x: 2160, y: 460, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 1, value: 100 },
      
      // Heart Pickup
      { id: 'l1_h1', x: 1840, y: 370, width: 24, height: 24, type: 'heart', collected: false, bobOffset: 0, value: 25 },
    ],
    hazards: [
      { x: 900, y: 550, width: 70, height: 50, type: 'spikes' },
      { x: 1590, y: 550, width: 80, height: 50, type: 'spikes' },
    ],
    enemies: [
      {
        id: 'e1_1',
        type: 'shadow_mouse',
        x: 520,
        y: 470,
        width: 36,
        height: 30,
        vx: 1.4,
        vy: 0,
        facing: -1,
        minX: 420,
        maxX: 720,
        health: 1,
        maxHealth: 1,
        stunTimer: 0,
        isDefeated: false,
        defeatTimer: 0,
        animFrame: 0,
        attackCooldown: 0,
      },
      {
        id: 'e1_2',
        type: 'shadow_mouse',
        x: 1240,
        y: 470,
        width: 36,
        height: 30,
        vx: 1.5,
        vy: 0,
        facing: 1,
        minX: 1100,
        maxX: 1480,
        health: 1,
        maxHealth: 1,
        stunTimer: 0,
        isDefeated: false,
        defeatTimer: 0,
        animFrame: 0,
        attackCooldown: 0,
      },
    ],
    boss: {
      name: 'Small Shadow Mouse',
      type: 'shadow_mouse',
      x: 1940,
      y: 450,
      maxHealth: 3,
    },
  },

  // ==========================================
  // LEVEL 2 — MODAKA MARKET (Introduce Dash)
  // ==========================================
  {
    id: 2,
    title: 'Modaka Market',
    subtitle: 'Sweets, Carts & Speedy Dashes',
    storySnippet: 'Mooshika reached the lively festival marketplace! Mischievous shadows have overturned fruit carts. Press SHIFT or the DASH button to burst through tight obstacles!',
    objective: 'Use Dash to navigate carts, collect 3 Modakas & beat the Market Guardian',
    environment: 'market',
    width: 2600,
    height: 600,
    playerStart: { x: 70, y: 440 },
    gate: { x: 2470, y: 400, width: 70, height: 110 },
    specialMechanic: 'Dash ability unlocked (Shift / Dash button)',
    ambientLighting: 1.0,
    platforms: [
      { x: 0, y: 510, width: 750, height: 90, type: 'solid' },
      // Moving flower carts
      { x: 320, y: 420, width: 110, height: 26, type: 'moving', vx: 1.8, minX: 280, maxX: 480 },
      { x: 550, y: 340, width: 130, height: 24, type: 'one_way' },
      
      // Awning section with narrow gap
      { x: 830, y: 510, width: 750, height: 90, type: 'solid' },
      { x: 920, y: 410, width: 120, height: 24, type: 'moving', vx: 1.6, minX: 880, maxX: 1080 },
      { x: 1150, y: 320, width: 130, height: 24, type: 'one_way' },
      { x: 1340, y: 400, width: 120, height: 24, type: 'moving', vy: 1.4, minY: 320, maxY: 430 },

      // High awnings
      { x: 1650, y: 510, width: 950, height: 90, type: 'solid' },
      { x: 1750, y: 410, width: 130, height: 24, type: 'one_way' },
      { x: 1980, y: 330, width: 140, height: 24, type: 'one_way' },
      { x: 2200, y: 410, width: 120, height: 24, type: 'one_way' },
    ],
    collectibles: [
      { id: 'l2_c1', x: 380, y: 370, width: 20, height: 20, type: 'coin', collected: false, bobOffset: 0, value: 10 },
      { id: 'l2_p1', x: 590, y: 290, width: 26, height: 26, type: 'powerup', powerUpType: 'festival_dash', collected: false, bobOffset: 1, value: 50 },
      // Modaka 1
      { id: 'l2_m1', x: 610, y: 220, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 2, value: 100 },
      
      { id: 'l2_c2', x: 960, y: 360, width: 20, height: 20, type: 'coin', collected: false, bobOffset: 3, value: 10 },
      { id: 'l2_b1', x: 1200, y: 270, width: 26, height: 26, type: 'bell', collected: false, bobOffset: 0, value: 50 },
      // Modaka 2 (Hidden above moving awning)
      { id: 'l2_m2', x: 1400, y: 250, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 1, value: 100 },
      
      { id: 'l2_f1', x: 1800, y: 360, width: 22, height: 22, type: 'flower', collected: false, bobOffset: 2, value: 15 },
      { id: 'l2_f2', x: 2030, y: 280, width: 22, height: 22, type: 'flower', collected: false, bobOffset: 3, value: 15 },
      // Modaka 3
      { id: 'l2_m3', x: 2250, y: 360, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 0, value: 100 },
    ],
    hazards: [
      { x: 750, y: 540, width: 80, height: 60, type: 'spikes' },
      { x: 1580, y: 540, width: 70, height: 60, type: 'spikes' },
      // Falling festive coconuts
      { x: 1050, y: 200, width: 24, height: 24, type: 'falling_pot', vy: 3.2, active: true },
      { x: 1450, y: 190, width: 24, height: 24, type: 'falling_pot', vy: 3.5, active: true },
    ],
    enemies: [
      {
        id: 'e2_1',
        type: 'shadow_imp',
        x: 480,
        y: 460,
        width: 36,
        height: 34,
        vx: 1.8,
        vy: 0,
        facing: -1,
        minX: 380,
        maxX: 640,
        health: 2,
        maxHealth: 2,
        stunTimer: 0,
        isDefeated: false,
        defeatTimer: 0,
        animFrame: 0,
        attackCooldown: 0,
      },
      {
        id: 'e2_2',
        type: 'shadow_imp',
        x: 1200,
        y: 460,
        width: 36,
        height: 34,
        vx: 1.6,
        vy: 0,
        facing: 1,
        minX: 1050,
        maxX: 1450,
        health: 2,
        maxHealth: 2,
        stunTimer: 0,
        isDefeated: false,
        defeatTimer: 0,
        animFrame: 0,
        attackCooldown: 0,
      },
    ],
    boss: {
      name: 'Market Guardian',
      type: 'shadow_imp',
      x: 2150,
      y: 440,
      maxHealth: 4,
    },
  },

  // ==========================================
  // LEVEL 3 — TEMPLE PATH (Introduce Wall Jump & Switches)
  // ==========================================
  {
    id: 3,
    title: 'Temple Path',
    subtitle: 'Stone Pillars & Ancient Switches',
    storySnippet: 'Grand stone gopurams lead to the temple sanctum. Mooshika can slide along stone walls and jump again to scale high shafts! Step on glowing stone switches to open sealed gateways.',
    objective: 'Press the temple switch, scale stone shafts with Wall Jump & defeat the Stone Guardian',
    environment: 'temple',
    width: 2700,
    height: 620,
    playerStart: { x: 80, y: 460 },
    gate: { x: 2540, y: 420, width: 70, height: 110 },
    specialMechanic: 'Wall Jump unlocked (Jump against vertical walls)',
    ambientLighting: 0.95,
    platforms: [
      { x: 0, y: 530, width: 680, height: 90, type: 'solid' },
      // Pillar 1
      { x: 280, y: 410, width: 90, height: 24, type: 'solid' },
      { x: 440, y: 310, width: 100, height: 24, type: 'solid' },
      
      // Vertical Wall Shaft for Wall Jumping
      { x: 680, y: 180, width: 36, height: 350, type: 'solid' }, // Left wall
      { x: 860, y: 180, width: 36, height: 350, type: 'solid' }, // Right wall
      { x: 716, y: 530, width: 144, height: 90, type: 'solid' },
      // Ledge at top of shaft
      { x: 896, y: 260, width: 140, height: 24, type: 'solid' },

      // Puzzle Bridge section
      { x: 1100, y: 530, width: 550, height: 90, type: 'solid' },
      // Target platform opened by switch
      { x: 1320, y: 390, width: 130, height: 24, type: 'moving', vy: 0, minY: 280, maxY: 390 },
      { x: 1510, y: 300, width: 130, height: 24, type: 'solid' },

      // Boss Arena
      { x: 1780, y: 530, width: 920, height: 90, type: 'solid' },
      { x: 1940, y: 420, width: 120, height: 24, type: 'one_way' },
      { x: 2200, y: 420, width: 120, height: 24, type: 'one_way' },
    ],
    switches: [
      { id: 'sw1', targetPlatformId: 'bridge1', x: 1180, y: 512, width: 36, height: 18, isPressed: false },
    ],
    collectibles: [
      { id: 'l3_c1', x: 310, y: 360, width: 20, height: 20, type: 'coin', collected: false, bobOffset: 0, value: 10 },
      { id: 'l3_c2', x: 470, y: 260, width: 20, height: 20, type: 'coin', collected: false, bobOffset: 1, value: 10 },
      // Modaka 1 (At top of wall jump shaft)
      { id: 'l3_m1', x: 770, y: 200, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 2, value: 100 },
      
      { id: 'l3_b1', x: 940, y: 210, width: 26, height: 26, type: 'bell', collected: false, bobOffset: 3, value: 50 },
      // Modaka 2 (Above switch area)
      { id: 'l3_m2', x: 1370, y: 230, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 0, value: 100 },
      
      { id: 'l3_h1', x: 1560, y: 250, width: 24, height: 24, type: 'heart', collected: false, bobOffset: 1, value: 25 },
      // Modaka 3 (Secret alcove in boss arena)
      { id: 'l3_m3', x: 2350, y: 470, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 2, value: 100 },
    ],
    hazards: [
      { x: 1044, y: 560, width: 56, height: 60, type: 'spikes' },
      { x: 1650, y: 560, width: 130, height: 60, type: 'spikes' },
    ],
    enemies: [
      {
        id: 'e3_1',
        type: 'stone_guardian',
        x: 500,
        y: 470,
        width: 42,
        height: 48,
        vx: 1.1,
        vy: 0,
        facing: -1,
        minX: 400,
        maxX: 620,
        health: 3,
        maxHealth: 3,
        stunTimer: 0,
        isDefeated: false,
        defeatTimer: 0,
        animFrame: 0,
        attackCooldown: 0,
      },
      {
        id: 'e3_2',
        type: 'shadow_imp',
        x: 1350,
        y: 470,
        width: 36,
        height: 34,
        vx: 1.7,
        vy: 0,
        facing: 1,
        minX: 1220,
        maxX: 1540,
        health: 2,
        maxHealth: 2,
        stunTimer: 0,
        isDefeated: false,
        defeatTimer: 0,
        animFrame: 0,
        attackCooldown: 0,
      },
    ],
    boss: {
      name: 'Ancient Stone Guardian',
      type: 'stone_guardian',
      x: 2100,
      y: 440,
      maxHealth: 5,
    },
  },

  // ==========================================
  // LEVEL 4 — LOTUS FOREST (Introduce Lotus Shield & Bouncy Petals)
  // ==========================================
  {
    id: 4,
    title: 'Lotus Forest',
    subtitle: 'Bouncy Petals & The Sacred Shield',
    storySnippet: 'Beyond the temple lies an enchanted grove adorned with glowing lotus blooms. Bouncing on the pink lotus pads launches Mooshika into the canopy! Find the divine Lotus Shield to withstand enemy strikes.',
    objective: 'Bounce on giant lotus flowers, find the Lotus Shield and gather 3 Modakas',
    environment: 'forest',
    width: 2800,
    height: 600,
    playerStart: { x: 80, y: 440 },
    gate: { x: 2650, y: 400, width: 70, height: 110 },
    specialMechanic: 'Bouncy Lotus Flowers & Lotus Shield Power-Up',
    ambientLighting: 0.9,
    platforms: [
      { x: 0, y: 510, width: 620, height: 90, type: 'solid' },
      // Bouncy Lotus 1
      { x: 420, y: 490, width: 64, height: 22, type: 'bouncy_lotus' },
      // High canopy branch
      { x: 490, y: 280, width: 140, height: 22, type: 'one_way' },
      { x: 700, y: 210, width: 130, height: 22, type: 'moving', vx: 1.7, minX: 660, maxX: 840 },

      // Midground trees
      { x: 880, y: 510, width: 740, height: 90, type: 'solid' },
      { x: 1040, y: 410, width: 110, height: 22, type: 'one_way' },
      // Bouncy Lotus 2
      { x: 1220, y: 490, width: 64, height: 22, type: 'bouncy_lotus' },
      { x: 1260, y: 260, width: 150, height: 22, type: 'one_way' },
      { x: 1480, y: 350, width: 130, height: 22, type: 'moving', vy: 1.4, minY: 260, maxY: 380 },

      // Boss Canopy
      { x: 1780, y: 510, width: 1020, height: 90, type: 'solid' },
      { x: 1940, y: 400, width: 120, height: 22, type: 'one_way' },
      { x: 2220, y: 400, width: 120, height: 22, type: 'one_way' },
    ],
    collectibles: [
      { id: 'l4_c1', x: 540, y: 230, width: 20, height: 20, type: 'coin', collected: false, bobOffset: 0, value: 10 },
      // Lotus Shield Power-Up
      { id: 'l4_p1', x: 750, y: 150, width: 28, height: 28, type: 'powerup', powerUpType: 'lotus_shield', collected: false, bobOffset: 1, value: 50 },
      // Modaka 1 (High in the canopy)
      { id: 'l4_m1', x: 800, y: 130, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 2, value: 100 },
      
      { id: 'l4_f1', x: 1080, y: 360, width: 22, height: 22, type: 'flower', collected: false, bobOffset: 3, value: 15 },
      // Modaka 2 (Above bouncy lotus 2)
      { id: 'l4_m2', x: 1320, y: 180, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 0, value: 100 },
      
      { id: 'l4_b1', x: 1530, y: 290, width: 26, height: 26, type: 'bell', collected: false, bobOffset: 1, value: 50 },
      // Modaka 3 (Secret hollow)
      { id: 'l4_m3', x: 2420, y: 460, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 2, value: 100 },
    ],
    hazards: [
      { x: 620, y: 550, width: 260, height: 50, type: 'spikes' },
      { x: 1620, y: 550, width: 160, height: 50, type: 'spikes' },
    ],
    enemies: [
      {
        id: 'e4_1',
        type: 'shadow_crow',
        x: 620,
        y: 260,
        width: 34,
        height: 28,
        vx: 2.1,
        vy: 0,
        facing: -1,
        minX: 520,
        maxX: 820,
        health: 1,
        maxHealth: 1,
        stunTimer: 0,
        isDefeated: false,
        defeatTimer: 0,
        animFrame: 0,
        attackCooldown: 0,
      },
      {
        id: 'e4_2',
        type: 'shadow_crow',
        x: 1380,
        y: 280,
        width: 34,
        height: 28,
        vx: 2.3,
        vy: 0,
        facing: 1,
        minX: 1250,
        maxX: 1560,
        health: 1,
        maxHealth: 1,
        stunTimer: 0,
        isDefeated: false,
        defeatTimer: 0,
        animFrame: 0,
        attackCooldown: 0,
      },
    ],
    boss: {
      name: 'Forest Shadow Queen',
      type: 'shadow_crow',
      x: 2150,
      y: 350,
      maxHealth: 5,
    },
  },

  // ==========================================
  // LEVEL 5 — RIVER FESTIVAL (Boat Riding & Water Hazards)
  // ==========================================
  {
    id: 5,
    title: 'River Festival',
    subtitle: 'Floating Diyas & River Barges',
    storySnippet: 'The sacred river glimmers with thousands of floating flower lamps for Vinayagar Chavurthi! Jump between drifting festival boats and ride the ceremonial barge across deep waters.',
    objective: 'Ride boats across the river, collect 3 Modakas and dispel the River Shadow',
    environment: 'river',
    width: 2900,
    height: 600,
    playerStart: { x: 70, y: 440 },
    gate: { x: 2750, y: 400, width: 70, height: 110 },
    specialMechanic: 'Drifting festival boats & dangerous water',
    ambientLighting: 0.95,
    platforms: [
      { x: 0, y: 510, width: 420, height: 90, type: 'solid' },
      
      // Floating boats across river
      { x: 480, y: 480, width: 120, height: 30, type: 'boat', vx: 1.5, minX: 450, maxX: 640 },
      { x: 720, y: 440, width: 110, height: 28, type: 'boat', vy: 1.2, minY: 420, maxY: 480 },
      { x: 920, y: 470, width: 130, height: 30, type: 'boat', vx: -1.7, minX: 860, maxX: 1060 },
      
      // River Pier
      { x: 1180, y: 510, width: 380, height: 90, type: 'solid' },
      
      // Big ceremonial river barge
      { x: 1650, y: 480, width: 180, height: 35, type: 'boat', vx: 2.2, minX: 1600, maxX: 2000 },
      { x: 2080, y: 440, width: 120, height: 28, type: 'boat', vy: 1.5, minY: 410, maxY: 480 },

      // Island Sanctuary (Boss)
      { x: 2280, y: 510, width: 620, height: 90, type: 'solid' },
      { x: 2420, y: 410, width: 120, height: 22, type: 'one_way' },
      { x: 2600, y: 410, width: 120, height: 22, type: 'one_way' },
    ],
    collectibles: [
      { id: 'l5_c1', x: 530, y: 420, width: 20, height: 20, type: 'coin', collected: false, bobOffset: 0, value: 10 },
      // Modaka 1 (Floating over the first river crossing)
      { id: 'l5_m1', x: 770, y: 350, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 1, value: 100 },
      
      { id: 'l5_f1', x: 970, y: 400, width: 22, height: 22, type: 'flower', collected: false, bobOffset: 2, value: 15 },
      { id: 'l5_b1', x: 1320, y: 440, width: 26, height: 26, type: 'bell', collected: false, bobOffset: 3, value: 50 },
      
      // Modaka 2 (Above the grand moving barge)
      { id: 'l5_m2', x: 1780, y: 360, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 0, value: 100 },
      
      { id: 'l5_h1', x: 2130, y: 380, width: 24, height: 24, type: 'heart', collected: false, bobOffset: 1, value: 25 },
      // Modaka 3 (High above the island temple)
      { id: 'l5_m3', x: 2510, y: 330, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 2, value: 100 },
    ],
    hazards: [
      // Holy river water is deep and treacherous
      { x: 420, y: 530, width: 760, height: 70, type: 'water' },
      { x: 1560, y: 530, width: 720, height: 70, type: 'water' },
    ],
    enemies: [
      {
        id: 'e5_1',
        type: 'river_shadow',
        x: 1300,
        y: 460,
        width: 38,
        height: 32,
        vx: 1.8,
        vy: 0,
        facing: -1,
        minX: 1200,
        maxX: 1500,
        health: 2,
        maxHealth: 2,
        stunTimer: 0,
        isDefeated: false,
        defeatTimer: 0,
        animFrame: 0,
        attackCooldown: 0,
      },
    ],
    boss: {
      name: 'River Shadow Fiend',
      type: 'river_shadow',
      x: 2520,
      y: 440,
      maxHealth: 6,
    },
  },

  // ==========================================
  // LEVEL 6 — DRUM HILLS (Drum Bounce & Combos)
  // ==========================================
  {
    id: 6,
    title: 'Drum Hills',
    subtitle: 'Rhythmic Bounces & Fast Combos',
    storySnippet: 'Giant festival Mridangams and Dhols echo through the hills! Landing on the drum tops launches Mooshika into the stratosphere with a resonant boom. String together bounces and collectibles for huge combos!',
    objective: 'Chain drum bounces, collect 3 Modakas and conquer the hill crest',
    environment: 'hills',
    width: 2900,
    height: 600,
    playerStart: { x: 80, y: 440 },
    gate: { x: 2740, y: 400, width: 70, height: 110 },
    specialMechanic: 'Drum Bounces & Score Combo System',
    ambientLighting: 1.0,
    platforms: [
      { x: 0, y: 510, width: 520, height: 90, type: 'solid' },
      // Giant Mridangam Drum 1
      { x: 380, y: 470, width: 84, height: 40, type: 'drum' },
      // Floating hill ledges
      { x: 560, y: 280, width: 140, height: 22, type: 'one_way' },
      
      // Giant Dhol Drum 2
      { x: 780, y: 480, width: 90, height: 40, type: 'drum' },
      { x: 920, y: 220, width: 150, height: 22, type: 'one_way' },
      
      // Mid hill plateau
      { x: 1150, y: 510, width: 550, height: 90, type: 'solid' },
      // Giant Drum 3
      { x: 1480, y: 470, width: 88, height: 40, type: 'drum' },
      { x: 1650, y: 260, width: 140, height: 22, type: 'moving', vx: 1.8, minX: 1600, maxX: 1840 },

      // High drum sequence
      { x: 1920, y: 480, width: 90, height: 40, type: 'drum' },
      { x: 2080, y: 320, width: 130, height: 22, type: 'one_way' },
      
      // Summit Plateau (Boss)
      { x: 2300, y: 510, width: 600, height: 90, type: 'solid' },
      { x: 2450, y: 410, width: 120, height: 22, type: 'one_way' },
      { x: 2620, y: 410, width: 120, height: 22, type: 'one_way' },
    ],
    collectibles: [
      { id: 'l6_c1', x: 420, y: 290, width: 20, height: 20, type: 'coin', collected: false, bobOffset: 0, value: 10 },
      // Modaka 1 (Catapulted high above Drum 1)
      { id: 'l6_m1', x: 420, y: 150, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 1, value: 100 },
      
      { id: 'l6_b1', x: 980, y: 160, width: 26, height: 26, type: 'bell', collected: false, bobOffset: 2, value: 50 },
      { id: 'l6_f1', x: 1280, y: 460, width: 22, height: 22, type: 'flower', collected: false, bobOffset: 3, value: 15 },
      
      // Modaka 2 (Sky high between moving hill platforms)
      { id: 'l6_m2', x: 1720, y: 180, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 0, value: 100 },
      
      { id: 'l6_h1', x: 2130, y: 260, width: 24, height: 24, type: 'heart', collected: false, bobOffset: 1, value: 25 },
      // Modaka 3 (Summit guard)
      { id: 'l6_m3', x: 2530, y: 340, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 2, value: 100 },
    ],
    hazards: [
      { x: 520, y: 550, width: 260, height: 50, type: 'spikes' },
      { x: 870, y: 550, width: 280, height: 50, type: 'spikes' },
      { x: 1700, y: 550, width: 220, height: 50, type: 'spikes' },
      { x: 2010, y: 550, width: 290, height: 50, type: 'spikes' },
    ],
    enemies: [
      {
        id: 'e6_1',
        type: 'shadow_imp',
        x: 1280,
        y: 460,
        width: 36,
        height: 34,
        vx: 1.8,
        vy: 0,
        facing: 1,
        minX: 1180,
        maxX: 1440,
        health: 2,
        maxHealth: 2,
        stunTimer: 0,
        isDefeated: false,
        defeatTimer: 0,
        animFrame: 0,
        attackCooldown: 0,
      },
    ],
    boss: {
      name: 'Rhythm Shadow Berserker',
      type: 'shadow_imp',
      x: 2540,
      y: 440,
      maxHealth: 6,
    },
  },

  // ==========================================
  // LEVEL 7 — CLOUD TEMPLE (Wind Zones & Sky Dash)
  // ==========================================
  {
    id: 7,
    title: 'Cloud Temple',
    subtitle: 'Gusty Winds & Celestial Spires',
    storySnippet: 'High above the clouds floats the celestial aerial temple! Gentle updrafts carry Mooshika higher, but storm clouds crackle with electric sparks. Collect the Sky Dash to soar through the winds.',
    objective: 'Ride wind drafts, evade lightning and retrieve 3 Modakas',
    environment: 'clouds',
    width: 3000,
    height: 600,
    playerStart: { x: 80, y: 440 },
    gate: { x: 2840, y: 400, width: 70, height: 110 },
    specialMechanic: 'Upward Wind Currents & Sky Dash Power-Up',
    ambientLighting: 1.0,
    wind: { vx: 0.8, vy: -0.15 },
    platforms: [
      { x: 0, y: 510, width: 450, height: 90, type: 'solid' },
      // Floating cloud platforms
      { x: 380, y: 410, width: 120, height: 22, type: 'one_way' },
      { x: 560, y: 320, width: 130, height: 22, type: 'moving', vy: 1.5, minY: 280, maxY: 400 },
      { x: 770, y: 240, width: 140, height: 22, type: 'one_way' },

      // Middle Sky Island
      { x: 1020, y: 490, width: 450, height: 90, type: 'solid' },
      { x: 1200, y: 380, width: 120, height: 22, type: 'one_way' },
      { x: 1380, y: 290, width: 130, height: 22, type: 'moving', vx: 1.8, minX: 1340, maxX: 1560 },

      // High Celestial Columns
      { x: 1680, y: 480, width: 120, height: 24, type: 'one_way' },
      { x: 1880, y: 390, width: 130, height: 24, type: 'one_way' },
      { x: 2100, y: 300, width: 140, height: 24, type: 'one_way' },

      // Celestial Temple Sanctum (Boss)
      { x: 2380, y: 510, width: 620, height: 90, type: 'solid' },
      { x: 2520, y: 400, width: 120, height: 22, type: 'one_way' },
      { x: 2720, y: 400, width: 120, height: 22, type: 'one_way' },
    ],
    collectibles: [
      { id: 'l7_c1', x: 420, y: 360, width: 20, height: 20, type: 'coin', collected: false, bobOffset: 0, value: 10 },
      // Sky Dash Power-Up
      { id: 'l7_p1', x: 830, y: 170, width: 28, height: 28, type: 'powerup', powerUpType: 'festival_dash', collected: false, bobOffset: 1, value: 50 },
      // Modaka 1
      { id: 'l7_m1', x: 850, y: 100, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 2, value: 100 },
      
      { id: 'l7_b1', x: 1240, y: 320, width: 26, height: 26, type: 'bell', collected: false, bobOffset: 3, value: 50 },
      // Modaka 2 (Floating between sky currents)
      { id: 'l7_m2', x: 1440, y: 220, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 0, value: 100 },
      
      { id: 'l7_h1', x: 1930, y: 330, width: 24, height: 24, type: 'heart', collected: false, bobOffset: 1, value: 25 },
      // Modaka 3
      { id: 'l7_m3', x: 2620, y: 330, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 2, value: 100 },
    ],
    hazards: [
      { x: 450, y: 570, width: 570, height: 50, type: 'water' }, // Fall into endless sky void
      { x: 1470, y: 570, width: 910, height: 50, type: 'water' },
      { x: 1100, y: 310, width: 28, height: 28, type: 'lightning', active: true },
      { x: 1750, y: 220, width: 28, height: 28, type: 'lightning', active: true },
    ],
    enemies: [
      {
        id: 'e7_1',
        type: 'cloud_guardian',
        x: 620,
        y: 280,
        width: 36,
        height: 32,
        vx: 2.2,
        vy: 0,
        facing: -1,
        minX: 520,
        maxX: 760,
        health: 2,
        maxHealth: 2,
        stunTimer: 0,
        isDefeated: false,
        defeatTimer: 0,
        animFrame: 0,
        attackCooldown: 0,
      },
      {
        id: 'e7_2',
        type: 'cloud_guardian',
        x: 1800,
        y: 350,
        width: 36,
        height: 32,
        vx: 2.4,
        vy: 0,
        facing: 1,
        minX: 1700,
        maxX: 1980,
        health: 2,
        maxHealth: 2,
        stunTimer: 0,
        isDefeated: false,
        defeatTimer: 0,
        animFrame: 0,
        attackCooldown: 0,
      },
    ],
    boss: {
      name: 'Sky Storm Sovereign',
      type: 'cloud_guardian',
      x: 2620,
      y: 430,
      maxHealth: 6,
    },
  },

  // ==========================================
  // LEVEL 8 — SHADOW CAVE (Darkness & Magical Lamps)
  // ==========================================
  {
    id: 8,
    title: 'Shadow Cave',
    subtitle: 'Deep Darkness & Divine Diya Lamps',
    storySnippet: 'The thieves retreated into an ancient subterranean cavern shrouded in magical darkness. Light up the sacred brass diyas along your path to illuminate invisible platforms and reveal hidden Modakas!',
    objective: 'Light temple lamps to reveal hidden paths and defeat the Shadow Beast',
    environment: 'cave',
    width: 2900,
    height: 600,
    playerStart: { x: 70, y: 440 },
    gate: { x: 2750, y: 400, width: 70, height: 110 },
    specialMechanic: 'Darkness mechanic & Divine Light revealing hidden paths',
    ambientLighting: 0.15, // Cave is dark!
    platforms: [
      { x: 0, y: 510, width: 550, height: 90, type: 'solid' },
      // Hidden platforms only solid or visible when lit
      { x: 420, y: 410, width: 120, height: 24, type: 'hidden', revealed: false },
      { x: 600, y: 320, width: 130, height: 24, type: 'hidden', revealed: false },
      { x: 790, y: 240, width: 120, height: 24, type: 'one_way' },

      // Central cavern ledge
      { x: 980, y: 510, width: 520, height: 90, type: 'solid' },
      { x: 1150, y: 410, width: 120, height: 24, type: 'hidden', revealed: false },
      { x: 1340, y: 310, width: 130, height: 24, type: 'moving', vy: 1.4, minY: 280, maxY: 400 },

      // Deep abyss bridges
      { x: 1650, y: 460, width: 120, height: 24, type: 'hidden', revealed: false },
      { x: 1850, y: 370, width: 130, height: 24, type: 'one_way' },
      { x: 2060, y: 290, width: 120, height: 24, type: 'hidden', revealed: false },

      // Boss Chamber
      { x: 2280, y: 510, width: 620, height: 90, type: 'solid' },
      { x: 2440, y: 410, width: 120, height: 22, type: 'one_way' },
      { x: 2620, y: 410, width: 120, height: 22, type: 'one_way' },
    ],
    lamps: [
      { id: 'lamp1', x: 240, y: 470, width: 30, height: 40, lit: true, radius: 190 },
      { id: 'lamp2', x: 830, y: 200, width: 30, height: 40, lit: false, radius: 220 },
      { id: 'lamp3', x: 1200, y: 470, width: 30, height: 40, lit: false, radius: 220 },
      { id: 'lamp4', x: 1900, y: 330, width: 30, height: 40, lit: false, radius: 220 },
      { id: 'lamp5', x: 2360, y: 470, width: 30, height: 40, lit: true, radius: 280 },
    ],
    collectibles: [
      // Divine Light powerup
      { id: 'l8_p1', x: 280, y: 450, width: 26, height: 26, type: 'powerup', powerUpType: 'divine_light', collected: false, bobOffset: 0, value: 50 },
      // Modaka 1 (Revealed by Lamp 2)
      { id: 'l8_m1', x: 650, y: 270, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 1, value: 100 },
      
      { id: 'l8_c1', x: 1050, y: 460, width: 20, height: 20, type: 'coin', collected: false, bobOffset: 2, value: 10 },
      // Modaka 2 (In high stalactite alcove)
      { id: 'l8_m2', x: 1390, y: 240, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 3, value: 100 },
      
      { id: 'l8_b1', x: 1890, y: 320, width: 26, height: 26, type: 'bell', collected: false, bobOffset: 0, value: 50 },
      // Modaka 3 (Near boss gate)
      { id: 'l8_m3', x: 2680, y: 350, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 1, value: 100 },
    ],
    hazards: [
      { x: 550, y: 550, width: 430, height: 50, type: 'spikes' },
      { x: 1500, y: 550, width: 780, height: 50, type: 'spikes' },
    ],
    enemies: [
      {
        id: 'e8_1',
        type: 'shadow_beast',
        x: 1080,
        y: 450,
        width: 44,
        height: 42,
        vx: 1.4,
        vy: 0,
        facing: -1,
        minX: 1000,
        maxX: 1400,
        health: 3,
        maxHealth: 3,
        stunTimer: 0,
        isDefeated: false,
        defeatTimer: 0,
        animFrame: 0,
        attackCooldown: 0,
      },
    ],
    boss: {
      name: 'Shadow Beast of the Abyss',
      type: 'shadow_beast',
      x: 2520,
      y: 430,
      maxHealth: 7,
    },
  },

  // ==========================================
  // LEVEL 9 — FESTIVAL MOUNTAIN (Combined Skills & Time Challenge)
  // ==========================================
  {
    id: 9,
    title: 'Festival Mountain',
    subtitle: 'The Grand Ascent & Timed Gauntlet',
    storySnippet: 'The mighty sacred mountain peaks overlook the entire festival valley. Every skill Mooshika learned is tested: drum bounces, wall jumps, moving carts, and switches!',
    objective: 'Ascend the mountain within the target time, gather all 3 Modakas and defeat the Mountain Guardian',
    environment: 'mountain',
    width: 3200,
    height: 620,
    playerStart: { x: 80, y: 460 },
    gate: { x: 3040, y: 420, width: 70, height: 110 },
    timeLimit: 120, // 2 minutes target
    specialMechanic: 'Full synergy gauntlet (Wall jumps, drums, switches, speed combos)',
    ambientLighting: 0.95,
    platforms: [
      { x: 0, y: 530, width: 450, height: 90, type: 'solid' },
      
      // Drum bounce into wall shaft
      { x: 340, y: 490, width: 84, height: 40, type: 'drum' },
      
      // Wall jump shaft
      { x: 520, y: 160, width: 34, height: 370, type: 'solid' },
      { x: 690, y: 160, width: 34, height: 370, type: 'solid' },
      { x: 554, y: 530, width: 136, height: 90, type: 'solid' },
      { x: 724, y: 220, width: 140, height: 22, type: 'one_way' },

      // Bouncy Lotus + Moving Carts
      { x: 950, y: 530, width: 550, height: 90, type: 'solid' },
      { x: 1040, y: 508, width: 64, height: 22, type: 'bouncy_lotus' },
      { x: 1180, y: 340, width: 130, height: 22, type: 'moving', vx: 1.8, minX: 1120, maxX: 1380 },
      { x: 1420, y: 260, width: 140, height: 22, type: 'one_way' },

      // Puzzle Switch area
      { x: 1680, y: 530, width: 480, height: 90, type: 'solid' },
      { x: 1900, y: 410, width: 120, height: 22, type: 'moving', vy: 1.4, minY: 300, maxY: 410 },
      { x: 2060, y: 300, width: 130, height: 22, type: 'one_way' },

      // Mountain Drum Peak
      { x: 2260, y: 500, width: 88, height: 40, type: 'drum' },
      { x: 2420, y: 310, width: 130, height: 22, type: 'one_way' },

      // Summit Arena (Boss)
      { x: 2650, y: 530, width: 550, height: 90, type: 'solid' },
      { x: 2790, y: 420, width: 120, height: 22, type: 'one_way' },
      { x: 2970, y: 420, width: 120, height: 22, type: 'one_way' },
    ],
    switches: [
      { id: 'm_sw1', targetPlatformId: 'm_gate', x: 1740, y: 512, width: 36, height: 18, isPressed: false },
    ],
    collectibles: [
      { id: 'l9_c1', x: 380, y: 310, width: 20, height: 20, type: 'coin', collected: false, bobOffset: 0, value: 10 },
      // Modaka 1 (At apex of wall shaft)
      { id: 'l9_m1', x: 605, y: 170, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 1, value: 100 },
      
      { id: 'l9_p1', x: 760, y: 170, width: 26, height: 26, type: 'powerup', powerUpType: 'lotus_shield', collected: false, bobOffset: 2, value: 50 },
      // Modaka 2 (Above moving mountain cart)
      { id: 'l9_m2', x: 1240, y: 270, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 3, value: 100 },
      
      { id: 'l9_b1', x: 1800, y: 470, width: 26, height: 26, type: 'bell', collected: false, bobOffset: 0, value: 50 },
      // Modaka 3 (Skyward mountain ridge)
      { id: 'l9_m3', x: 2300, y: 190, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 1, value: 100 },
    ],
    hazards: [
      { x: 450, y: 570, width: 104, height: 50, type: 'spikes' },
      { x: 690, y: 570, width: 260, height: 50, type: 'spikes' },
      { x: 1500, y: 570, width: 180, height: 50, type: 'spikes' },
      { x: 2160, y: 570, width: 490, height: 50, type: 'spikes' },
    ],
    enemies: [
      {
        id: 'e9_1',
        type: 'mountain_guardian',
        x: 1080,
        y: 470,
        width: 44,
        height: 48,
        vx: 1.5,
        vy: 0,
        facing: -1,
        minX: 980,
        maxX: 1400,
        health: 3,
        maxHealth: 3,
        stunTimer: 0,
        isDefeated: false,
        defeatTimer: 0,
        animFrame: 0,
        attackCooldown: 0,
      },
    ],
    boss: {
      name: 'Colossal Mountain Guardian',
      type: 'mountain_guardian',
      x: 2880,
      y: 450,
      maxHealth: 7,
    },
  },

  // ==========================================
  // LEVEL 10 — THE FINAL FESTIVAL (Grand 3-Phase Boss Battle)
  // ==========================================
  {
    id: 10,
    title: 'The Final Festival',
    subtitle: 'The Grand Pandal & The Shadow of Chaos',
    storySnippet: 'Mooshika reaches the sacred central pandal of Lord Vinayagar! The master of all mischief, "THE SHADOW OF CHAOS", has sealed the divine altar. Purify the shadow boss to restore the light and save the festival!',
    objective: 'Complete the celestial gauntlet and defeat THE SHADOW OF CHAOS!',
    environment: 'final',
    width: 3200,
    height: 620,
    playerStart: { x: 90, y: 460 },
    gate: { x: 3050, y: 420, width: 70, height: 110 },
    specialMechanic: 'Multi-phase final boss: attack telegraphs, shockwaves, vulnerable recovery phases',
    ambientLighting: 0.9,
    platforms: [
      // Phase 1 Platforming Challenge
      { x: 0, y: 530, width: 500, height: 90, type: 'solid' },
      { x: 380, y: 420, width: 130, height: 22, type: 'one_way' },
      // Drum launch
      { x: 540, y: 490, width: 86, height: 40, type: 'drum' },
      { x: 680, y: 250, width: 140, height: 22, type: 'one_way' },
      { x: 880, y: 320, width: 130, height: 22, type: 'moving', vx: 1.8, minX: 840, maxX: 1060 },
      { x: 1120, y: 240, width: 140, height: 22, type: 'one_way' },

      // Phase 2 Minion Arena
      { x: 1340, y: 530, width: 560, height: 90, type: 'solid' },
      { x: 1480, y: 420, width: 120, height: 22, type: 'one_way' },
      { x: 1680, y: 420, width: 120, height: 22, type: 'one_way' },

      // Transition Bridge
      { x: 1980, y: 460, width: 130, height: 22, type: 'one_way' },

      // Phase 3 Final Boss Grand Sanctum (Pandal)
      { x: 2180, y: 530, width: 1020, height: 90, type: 'solid' },
      { x: 2360, y: 410, width: 130, height: 22, type: 'one_way' },
      { x: 2600, y: 330, width: 140, height: 22, type: 'one_way' },
      { x: 2840, y: 410, width: 130, height: 22, type: 'one_way' },
    ],
    collectibles: [
      { id: 'l10_c1', x: 420, y: 370, width: 20, height: 20, type: 'coin', collected: false, bobOffset: 0, value: 10 },
      // Modaka 1
      { id: 'l10_m1', x: 740, y: 190, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 1, value: 100 },
      
      { id: 'l10_b1', x: 1180, y: 180, width: 26, height: 26, type: 'bell', collected: false, bobOffset: 2, value: 50 },
      // Modaka 2 (Phase 2 sanctum)
      { id: 'l10_m2', x: 1600, y: 360, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 3, value: 100 },
      
      // Full powerups before final battle
      { id: 'l10_h1', x: 2040, y: 410, width: 24, height: 24, type: 'heart', collected: false, bobOffset: 0, value: 25 },
      { id: 'l10_p1', x: 2240, y: 470, width: 28, height: 28, type: 'powerup', powerUpType: 'lotus_shield', collected: false, bobOffset: 1, value: 50 },
      // Final Sacred Modaka 3
      { id: 'l10_m3', x: 2660, y: 270, width: 28, height: 28, type: 'modaka', collected: false, bobOffset: 2, value: 100 },
    ],
    hazards: [
      { x: 500, y: 570, width: 840, height: 50, type: 'spikes' },
      { x: 1900, y: 570, width: 280, height: 50, type: 'spikes' },
    ],
    enemies: [
      {
        id: 'e10_1',
        type: 'shadow_imp',
        x: 1420,
        y: 470,
        width: 36,
        height: 34,
        vx: 2.0,
        vy: 0,
        facing: -1,
        minX: 1360,
        maxX: 1540,
        health: 2,
        maxHealth: 2,
        stunTimer: 0,
        isDefeated: false,
        defeatTimer: 0,
        animFrame: 0,
        attackCooldown: 0,
      },
      {
        id: 'e10_2',
        type: 'shadow_beast',
        x: 1720,
        y: 470,
        width: 44,
        height: 42,
        vx: 1.6,
        vy: 0,
        facing: 1,
        minX: 1600,
        maxX: 1860,
        health: 3,
        maxHealth: 3,
        stunTimer: 0,
        isDefeated: false,
        defeatTimer: 0,
        animFrame: 0,
        attackCooldown: 0,
      },
    ],
    boss: {
      name: 'THE SHADOW OF CHAOS',
      type: 'shadow_beast',
      x: 2750,
      y: 410,
      maxHealth: 10,
    },
  },
];
