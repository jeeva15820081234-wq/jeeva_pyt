/**
 * Mooshika: The Festival Guardian - High Performance Canvas 2D Renderer
 * Beautiful Indian festival aesthetics, procedural animations, parallax, and particles.
 */

import { LevelData, Platform, Collectible, Hazard, Enemy, Particle, FloatingText, Lamp, PuzzleSwitch } from './types';
import { CANVAS_WIDTH, CANVAS_HEIGHT } from './constants';

export class GameRenderer {
  private ctx: CanvasRenderingContext2D;
  private animTimer: number = 0;

  constructor(ctx: CanvasRenderingContext2D) {
    this.ctx = ctx;
  }

  public render(
    level: LevelData,
    cameraX: number,
    cameraY: number,
    player: {
      x: number;
      y: number;
      width: number;
      height: number;
      vx: number;
      vy: number;
      facing: 1 | -1;
      isGrounded: boolean;
      isDashing: boolean;
      isWallSliding: boolean;
      wallSlideDir: number;
      invulnerableTimer: number;
      activeShield: boolean;
      hasModakaPower: boolean;
      hasDivineLight: boolean;
      squash: number; // 1 = normal, >1 = wide/short, <1 = tall/skinny
    },
    particles: Particle[],
    floatingTexts: FloatingText[],
    projectiles: Array<{ x: number; y: number; width: number; height: number; type: string }>,
    screenShake: { x: number; y: number }
  ) {
    this.animTimer += 0.035;
    const ctx = this.ctx;

    ctx.save();
    // Apply screen shake
    ctx.translate(screenShake.x, screenShake.y);

    // 1. Draw Parallax Background
    this.drawParallaxBackground(level, cameraX, cameraY);

    // 2. World Space Rendering
    ctx.save();
    ctx.translate(-cameraX, -cameraY);

    // Environmental decorations (back layer)
    this.drawBackgroundDecorations(level, cameraX);

    // Platforms
    level.platforms.forEach(plat => this.drawPlatform(plat, level.environment));

    // Switches
    if (level.switches) {
      level.switches.forEach(sw => this.drawSwitch(sw));
    }

    // Lamps
    if (level.lamps) {
      level.lamps.forEach(lamp => this.drawLamp(lamp));
    }

    // Hazards
    level.hazards.forEach(haz => this.drawHazard(haz));

    // Collectibles
    level.collectibles.forEach(col => {
      if (!col.collected) {
        this.drawCollectible(col);
      }
    });

    // Festival Exit Gate
    this.drawFestivalGate(level.gate);

    // Enemies
    level.enemies.forEach(enemy => this.drawEnemy(enemy));

    // Projectiles & boss attacks
    projectiles.forEach(p => this.drawProjectile(p));

    // Player (Mooshika!)
    this.drawMooshika(player);

    // World Particles (petals, sparks, smoke)
    this.drawParticles(particles);

    // Floating Text (+10, MODAKA!, COMBO!)
    this.drawFloatingTexts(floatingTexts);

    ctx.restore(); // Exit world space

    // 3. Ambient Lighting & Cave Darkness Overlay
    this.drawLightingOverlay(level, cameraX, cameraY, player);

    ctx.restore(); // Exit screen shake
  }

  // ==========================================
  // PARALLAX BACKGROUND
  // ==========================================
  private drawParallaxBackground(level: LevelData, cameraX: number, _cameraY: number) {
    const ctx = this.ctx;
    const w = CANVAS_WIDTH;
    const h = CANVAS_HEIGHT;

    // Dynamic sky gradient based on environment
    const skyGrad = ctx.createLinearGradient(0, 0, 0, h);
    switch (level.environment) {
      case 'village':
      case 'market':
        // Warm twilight amber and saffron
        skyGrad.addColorStop(0, '#2e1065'); // twilight purple
        skyGrad.addColorStop(0.4, '#7c2d12'); // warm terracotta
        skyGrad.addColorStop(0.8, '#d97706'); // festival saffron
        skyGrad.addColorStop(1, '#fef08a'); // soft lantern glow
        break;
      case 'temple':
        skyGrad.addColorStop(0, '#1e1b4b');
        skyGrad.addColorStop(0.5, '#4c0519');
        skyGrad.addColorStop(0.85, '#b45309');
        skyGrad.addColorStop(1, '#fde68a');
        break;
      case 'forest':
        skyGrad.addColorStop(0, '#064e3b');
        skyGrad.addColorStop(0.5, '#047857');
        skyGrad.addColorStop(0.8, '#0d9488');
        skyGrad.addColorStop(1, '#a7f3d0');
        break;
      case 'river':
        skyGrad.addColorStop(0, '#0c4a6e');
        skyGrad.addColorStop(0.4, '#0284c7');
        skyGrad.addColorStop(0.8, '#38bdf8');
        skyGrad.addColorStop(1, '#bae6fd');
        break;
      case 'hills':
        skyGrad.addColorStop(0, '#431407');
        skyGrad.addColorStop(0.4, '#9a3412');
        skyGrad.addColorStop(0.75, '#ea580c');
        skyGrad.addColorStop(1, '#fed7aa');
        break;
      case 'clouds':
        skyGrad.addColorStop(0, '#1e3a8a');
        skyGrad.addColorStop(0.5, '#3b82f6');
        skyGrad.addColorStop(0.8, '#93c5fd');
        skyGrad.addColorStop(1, '#ffffff');
        break;
      case 'cave':
        skyGrad.addColorStop(0, '#090514');
        skyGrad.addColorStop(0.6, '#1e1035');
        skyGrad.addColorStop(1, '#2e1065');
        break;
      case 'mountain':
        skyGrad.addColorStop(0, '#311042');
        skyGrad.addColorStop(0.4, '#831843');
        skyGrad.addColorStop(0.8, '#c2410c');
        skyGrad.addColorStop(1, '#fde047');
        break;
      case 'final':
        skyGrad.addColorStop(0, '#180828');
        skyGrad.addColorStop(0.35, '#581c87');
        skyGrad.addColorStop(0.7, '#9333ea');
        skyGrad.addColorStop(1, '#f59e0b');
        break;
    }
    ctx.fillStyle = skyGrad;
    ctx.fillRect(0, 0, w, h);

    // Far silhouette mountains / temples (slow parallax: 0.15)
    ctx.save();
    ctx.fillStyle = 'rgba(20, 10, 35, 0.45)';
    const offset1 = (cameraX * 0.12) % 600;
    ctx.beginPath();
    ctx.moveTo(0, h);
    for (let x = -600; x < w + 600; x += 150) {
      const px = x - offset1;
      const peakY = h - 180 + Math.sin((x + 100) * 0.005) * 50;
      ctx.lineTo(px, peakY);
      // Temple gopuram tower silhouette every 450px
      if ((x / 150) % 3 === 0) {
        ctx.lineTo(px + 20, peakY - 45);
        ctx.lineTo(px + 35, peakY - 70); // Kalash pinnacle
        ctx.lineTo(px + 50, peakY - 45);
        ctx.lineTo(px + 70, peakY);
      }
    }
    ctx.lineTo(w, h);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // Midground silhouette hills & festival decorations (parallax: 0.35)
    ctx.save();
    ctx.fillStyle = 'rgba(24, 12, 42, 0.65)';
    const offset2 = (cameraX * 0.3) % 400;
    ctx.beginPath();
    ctx.moveTo(0, h);
    for (let x = -400; x < w + 400; x += 100) {
      const px = x - offset2;
      const hillY = h - 100 + Math.cos(x * 0.008) * 35;
      ctx.lineTo(px, hillY);
    }
    ctx.lineTo(w, h);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // Festive hanging Torans & Glowing Paper Lanterns in the sky
    this.drawHangingSkyTorans(w, h, cameraX);
  }

  private drawHangingSkyTorans(w: number, _h: number, cameraX: number) {
    const ctx = this.ctx;
    ctx.save();

    // Swaying string with marigold flowers and mango leaves
    const ropeY = 24;
    ctx.strokeStyle = 'rgba(245, 158, 11, 0.4)';
    ctx.lineWidth = 2;

    const span = 160;
    const startX = -((cameraX * 0.5) % span);

    for (let x = startX; x < w + span; x += span) {
      ctx.beginPath();
      ctx.moveTo(x, ropeY);
      ctx.quadraticCurveTo(x + span / 2, ropeY + 26, x + span, ropeY);
      ctx.stroke();

      // Hanging paper lamps / marigold pendants
      const midX = x + span / 2;
      const midY = ropeY + 22 + Math.sin(this.animTimer * 2 + x) * 3;

      // Glow halo
      const radGrad = ctx.createRadialGradient(midX, midY, 2, midX, midY, 22);
      radGrad.addColorStop(0, 'rgba(251, 191, 36, 0.7)');
      radGrad.addColorStop(1, 'rgba(251, 191, 36, 0)');
      ctx.fillStyle = radGrad;
      ctx.beginPath();
      ctx.arc(midX, midY, 22, 0, Math.PI * 2);
      ctx.fill();

      // Little festive lantern / diya
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(midX, midY, 6, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  }

  private drawBackgroundDecorations(level: LevelData, _cameraX: number) {
    const ctx = this.ctx;
    ctx.save();

    // In Level 10 Final Festival: Giant festive Vinayagar Arch and Pandal pillars
    if (level.environment === 'final') {
      const altarX = 2850;
      const altarY = 240;

      // Grand glowing Ganesha idol silhouette at the final altar
      const glowGrad = ctx.createRadialGradient(altarX, altarY + 80, 20, altarX, altarY + 80, 240);
      glowGrad.addColorStop(0, 'rgba(251, 191, 36, 0.45)');
      glowGrad.addColorStop(0.7, 'rgba(249, 115, 22, 0.2)');
      glowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = glowGrad;
      ctx.beginPath();
      ctx.arc(altarX, altarY + 80, 240, 0, Math.PI * 2);
      ctx.fill();

      // Golden ornate shrine pillars
      ctx.fillStyle = '#b45309';
      ctx.fillRect(altarX - 120, altarY - 20, 24, 280);
      ctx.fillRect(altarX + 100, altarY - 20, 24, 280);

      // Arch top
      ctx.beginPath();
      ctx.arc(altarX, altarY - 20, 120, Math.PI, 0);
      ctx.lineWidth = 16;
      ctx.strokeStyle = '#f59e0b';
      ctx.stroke();
    }

    ctx.restore();
  }

  // ==========================================
  // PLATFORMS RENDERING
  // ==========================================
  private drawPlatform(p: Platform, env: LevelData['environment']) {
    const ctx = this.ctx;
    ctx.save();

    // Check hidden platform visibility
    if (p.type === 'hidden' && !p.revealed) {
      // Draw as a faint ethereal shimmer
      ctx.strokeStyle = 'rgba(216, 180, 254, 0.35)';
      ctx.setLineDash([4, 4]);
      ctx.lineWidth = 2;
      ctx.strokeRect(p.x, p.y, p.width, p.height);
      ctx.restore();
      return;
    }

    if (p.type === 'drum') {
      // Giant Mridangam / Dhol drum platform
      this.drawDrumPlatform(p);
      ctx.restore();
      return;
    }

    if (p.type === 'bouncy_lotus') {
      // Giant glowing bouncy pink Lotus pad
      this.drawBouncyLotusPlatform(p);
      ctx.restore();
      return;
    }

    if (p.type === 'boat') {
      // Festival River Boat platform
      this.drawBoatPlatform(p);
      ctx.restore();
      return;
    }

    // Standard Solid / One-way Platforms
    let topColor = '#d97706'; // rich marigold gold
    let bodyColor = '#78350f'; // carved wood/stone
    let borderColor = '#fbbf24';

    if (env === 'temple' || env === 'mountain') {
      topColor = '#94a3b8';
      bodyColor = '#334155';
      borderColor = '#cbd5e1';
    } else if (env === 'forest') {
      topColor = '#10b981';
      bodyColor = '#064e3b';
      borderColor = '#34d399';
    } else if (env === 'clouds') {
      topColor = '#e0f2fe';
      bodyColor = '#38bdf8';
      borderColor = '#ffffff';
    } else if (env === 'cave') {
      topColor = '#8b5cf6';
      bodyColor = '#3b0764';
      borderColor = '#c084fc';
    }

    // Rounded platform body
    const radius = 8;
    ctx.fillStyle = bodyColor;
    ctx.beginPath();
    ctx.roundRect(p.x, p.y, p.width, p.height, [radius, radius, radius, radius]);
    ctx.fill();

    // Top surface trim
    ctx.fillStyle = topColor;
    ctx.beginPath();
    ctx.roundRect(p.x, p.y, p.width, Math.min(8, p.height), [radius, radius, 0, 0]);
    ctx.fill();

    // Subtle edge highlight
    ctx.strokeStyle = borderColor;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(p.x, p.y, p.width, p.height, [radius, radius, radius, radius]);
    ctx.stroke();

    // Festive Marigold Garland / Toran hanging underneath platforms
    if (p.width >= 90 && p.height <= 30) {
      this.drawToranUnderPlatform(p.x, p.y + p.height, p.width);
    }

    ctx.restore();
  }

  private drawToranUnderPlatform(x: number, y: number, width: number) {
    const ctx = this.ctx;
    ctx.save();
    const scallopWidth = 30;
    const count = Math.floor(width / scallopWidth);

    ctx.fillStyle = '#f59e0b';
    for (let i = 0; i < count; i++) {
      const cx = x + i * scallopWidth + scallopWidth / 2;
      const cy = y + 4;
      // Orange marigold blossom
      ctx.beginPath();
      ctx.arc(cx, cy, 3.5, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  private drawDrumPlatform(p: Platform) {
    const ctx = this.ctx;
    // Drum shell (terracotta / rich mahogany)
    const radius = 10;
    const grad = ctx.createLinearGradient(p.x, p.y, p.x + p.width, p.y);
    grad.addColorStop(0, '#991b1b');
    grad.addColorStop(0.5, '#dc2626');
    grad.addColorStop(1, '#991b1b');

    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.roundRect(p.x, p.y, p.width, p.height, [radius, radius, radius, radius]);
    ctx.fill();

    // Drumhead skin (parchment white with black mridangam eye / syahi in center)
    ctx.fillStyle = '#fef3c7';
    ctx.beginPath();
    ctx.ellipse(p.x + p.width / 2, p.y + 7, p.width * 0.45, 6, 0, 0, Math.PI * 2);
    ctx.fill();

    // Black central resonant circle (syahi)
    ctx.fillStyle = '#1e1b4b';
    ctx.beginPath();
    ctx.ellipse(p.x + p.width / 2, p.y + 7, p.width * 0.18, 2.5, 0, 0, Math.PI * 2);
    ctx.fill();

    // Gold tuning rings / straps along drum body
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2;
    for (let lx = p.x + 12; lx < p.x + p.width - 10; lx += 14) {
      ctx.beginPath();
      ctx.moveTo(lx, p.y + 12);
      ctx.lineTo(lx + 6, p.y + p.height - 4);
      ctx.stroke();
    }

    // Bouncing indicator glow
    ctx.strokeStyle = 'rgba(251, 191, 36, 0.8)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(p.x - 2, p.y - 2, p.width + 4, p.height + 4, [radius + 2]);
    ctx.stroke();
  }

  private drawBouncyLotusPlatform(p: Platform) {
    const ctx = this.ctx;
    const cx = p.x + p.width / 2;
    const cy = p.y + p.height / 2;

    // Outer green lily pad leaf
    ctx.fillStyle = '#059669';
    ctx.beginPath();
    ctx.ellipse(cx, cy + 3, p.width * 0.48, p.height * 0.5, 0, 0, Math.PI * 2);
    ctx.fill();

    // Layered pink lotus petals
    const petalColors = ['#ec4899', '#f472b6', '#fbcfe8'];
    petalColors.forEach((col, idx) => {
      ctx.fillStyle = col;
      const numPetals = 7;
      for (let i = 0; i < numPetals; i++) {
        const angle = (i / numPetals) * Math.PI + (idx * 0.2);
        const px = cx + Math.cos(angle) * (p.width * (0.4 - idx * 0.08));
        const py = cy - Math.sin(angle) * (p.height * (0.35 - idx * 0.05));
        ctx.beginPath();
        ctx.ellipse(px, py, 9, 6, angle, 0, Math.PI * 2);
        ctx.fill();
      }
    });

    // Golden pollen center that pulses
    const pulse = Math.sin(this.animTimer * 4) * 2;
    ctx.fillStyle = '#facc15';
    ctx.beginPath();
    ctx.arc(cx, cy - 2, 8 + pulse, 0, Math.PI * 2);
    ctx.fill();
  }

  private drawBoatPlatform(p: Platform) {
    const ctx = this.ctx;
    // Carved wooden festive boat
    ctx.save();
    ctx.fillStyle = '#78350f';
    ctx.beginPath();
    ctx.moveTo(p.x, p.y + 4);
    ctx.quadraticCurveTo(p.x + p.width * 0.1, p.y + p.height, p.x + p.width * 0.5, p.y + p.height);
    ctx.quadraticCurveTo(p.x + p.width * 0.9, p.y + p.height, p.x + p.width, p.y + 4);
    ctx.closePath();
    ctx.fill();

    // Golden rim and decorative flag
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(p.x - 4, p.y + 4);
    ctx.lineTo(p.x + p.width + 4, p.y + 4);
    ctx.stroke();

    // Diya lamp on boat bow
    ctx.fillStyle = '#fbbf24';
    ctx.beginPath();
    ctx.arc(p.x + 12, p.y - 2, 4, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  private drawSwitch(sw: PuzzleSwitch) {
    const ctx = this.ctx;
    ctx.save();
    // Stone base
    ctx.fillStyle = '#475569';
    ctx.fillRect(sw.x - 4, sw.y + sw.height - 4, sw.width + 8, 8);

    // Pressure plate
    const pressedOffset = sw.isPressed ? 6 : 0;
    ctx.fillStyle = sw.isPressed ? '#10b981' : '#f59e0b';
    ctx.beginPath();
    ctx.roundRect(sw.x, sw.y + pressedOffset, sw.width, sw.height - pressedOffset, [4, 4, 0, 0]);
    ctx.fill();

    // Glowing glyph
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(sw.x + sw.width / 2, sw.y + pressedOffset + 6, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  private drawLamp(lamp: Lamp) {
    const ctx = this.ctx;
    ctx.save();
    const cx = lamp.x + lamp.width / 2;
    const cy = lamp.y + lamp.height / 2;

    // Traditional tiered brass deepam / lamp stand
    ctx.fillStyle = '#d97706';
    ctx.fillRect(cx - 3, cy, 6, lamp.height / 2);
    // Base
    ctx.beginPath();
    ctx.ellipse(cx, lamp.y + lamp.height, 12, 4, 0, 0, Math.PI * 2);
    ctx.fill();
    // Bowl
    ctx.beginPath();
    ctx.ellipse(cx, cy, 10, 5, 0, 0, Math.PI * 2);
    ctx.fill();

    if (lamp.lit) {
      // Flickering flame
      const flicker = Math.sin(this.animTimer * 10 + lamp.x) * 2;
      ctx.fillStyle = '#fef08a';
      ctx.beginPath();
      ctx.moveTo(cx - 4, cy - 2);
      ctx.quadraticCurveTo(cx, cy - 14 + flicker, cx, cy - 16 + flicker);
      ctx.quadraticCurveTo(cx, cy - 14 + flicker, cx + 4, cy - 2);
      ctx.closePath();
      ctx.fill();

      // Golden warm glow halo
      const glow = ctx.createRadialGradient(cx, cy - 8, 2, cx, cy - 8, 36);
      glow.addColorStop(0, 'rgba(253, 224, 71, 0.6)');
      glow.addColorStop(1, 'rgba(253, 224, 71, 0)');
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(cx, cy - 8, 36, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  // ==========================================
  // HAZARDS
  // ==========================================
  private drawHazard(h: Hazard) {
    const ctx = this.ctx;
    ctx.save();

    if (h.type === 'spikes') {
      // Shadow thorn spikes / bamboo barricade
      ctx.fillStyle = '#374151';
      ctx.strokeStyle = '#4c1d95';
      ctx.lineWidth = 1.5;
      const spikeW = 16;
      const count = Math.ceil(h.width / spikeW);
      for (let i = 0; i < count; i++) {
        const sx = h.x + i * spikeW;
        ctx.beginPath();
        ctx.moveTo(sx, h.y + h.height);
        ctx.lineTo(sx + spikeW / 2, h.y);
        ctx.lineTo(sx + spikeW, h.y + h.height);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }
    } else if (h.type === 'water') {
      // Sacred river water with moving ripples
      const waterGrad = ctx.createLinearGradient(h.x, h.y, h.x, h.y + h.height);
      waterGrad.addColorStop(0, 'rgba(14, 165, 233, 0.85)');
      waterGrad.addColorStop(1, 'rgba(2, 132, 199, 0.95)');
      ctx.fillStyle = waterGrad;
      ctx.fillRect(h.x, h.y, h.width, h.height);

      // Water surface ripple
      ctx.strokeStyle = '#e0f2fe';
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let rx = h.x; rx < h.x + h.width; rx += 20) {
        const ry = h.y + Math.sin(this.animTimer * 3 + rx * 0.05) * 3;
        if (rx === h.x) ctx.moveTo(rx, ry);
        else ctx.lineTo(rx, ry);
      }
      ctx.stroke();
    } else if (h.type === 'falling_pot') {
      // Falling coconut / clay pot
      ctx.fillStyle = '#78350f';
      ctx.beginPath();
      ctx.arc(h.x + h.width / 2, h.y + h.height / 2, h.width / 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#d97706';
      ctx.lineWidth = 2;
      ctx.stroke();
    } else if (h.type === 'lightning') {
      // Celestial lightning spark
      ctx.strokeStyle = '#fef08a';
      ctx.lineWidth = 3;
      ctx.shadowColor = '#38bdf8';
      ctx.shadowBlur = 10;
      const lx = h.x + h.width / 2;
      ctx.beginPath();
      ctx.moveTo(lx, h.y);
      ctx.lineTo(lx - 6, h.y + h.height * 0.4);
      ctx.lineTo(lx + 6, h.y + h.height * 0.6);
      ctx.lineTo(lx, h.y + h.height);
      ctx.stroke();
    }
    ctx.restore();
  }

  // ==========================================
  // COLLECTIBLES RENDERING
  // ==========================================
  private drawCollectible(c: Collectible) {
    const ctx = this.ctx;
    ctx.save();
    const bob = Math.sin(this.animTimer * 4 + c.bobOffset) * 5;
    const cx = c.x + c.width / 2;
    const cy = c.y + c.height / 2 + bob;

    if (c.type === 'coin') {
      // Golden Coin with inner shimmer
      const spinScale = Math.abs(Math.cos(this.animTimer * 3 + c.bobOffset));
      ctx.translate(cx, cy);
      ctx.scale(Math.max(0.2, spinScale), 1);

      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(0, 0, c.width / 2, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#fef08a';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Om symbol or star stamp
      ctx.fillStyle = '#78350f';
      ctx.beginPath();
      ctx.arc(0, 0, c.width * 0.25, 0, Math.PI * 2);
      ctx.fill();
    } else if (c.type === 'modaka') {
      // Sacred Festival Modaka! (Golden sweet with pointed tip)
      // Glow aura
      const aura = ctx.createRadialGradient(cx, cy, 4, cx, cy, 26);
      aura.addColorStop(0, 'rgba(253, 224, 71, 0.7)');
      aura.addColorStop(1, 'rgba(253, 224, 71, 0)');
      ctx.fillStyle = aura;
      ctx.beginPath();
      ctx.arc(cx, cy, 26, 0, Math.PI * 2);
      ctx.fill();

      // Modaka dumpling shape
      ctx.fillStyle = '#fef9c3'; // pristine cream/white rice flour
      ctx.beginPath();
      ctx.moveTo(cx, cy - 14); // pointed tip
      ctx.quadraticCurveTo(cx + 12, cy - 6, cx + 13, cy + 6);
      ctx.quadraticCurveTo(cx + 8, cy + 13, cx, cy + 13);
      ctx.quadraticCurveTo(cx - 8, cy + 13, cx - 13, cy + 6);
      ctx.quadraticCurveTo(cx - 12, cy - 6, cx, cy - 14);
      ctx.closePath();
      ctx.fill();

      // Traditional modaka vertical pleats
      ctx.strokeStyle = '#fef08a';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(cx - 6, cy + 11);
      ctx.quadraticCurveTo(cx - 4, cy, cx, cy - 12);
      ctx.moveTo(cx, cy + 12);
      ctx.lineTo(cx, cy - 13);
      ctx.moveTo(cx + 6, cy + 11);
      ctx.quadraticCurveTo(cx + 4, cy, cx, cy - 12);
      ctx.stroke();

      // Saffron / Kesar mark on top
      ctx.fillStyle = '#ea580c';
      ctx.beginPath();
      ctx.arc(cx, cy - 13, 2.5, 0, Math.PI * 2);
      ctx.fill();

      // Sparkle
      const sparkleX = cx + Math.cos(this.animTimer * 4) * 16;
      const sparkleY = cy + Math.sin(this.animTimer * 4) * 16;
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(sparkleX, sparkleY, 1.8, 0, Math.PI * 2);
      ctx.fill();
    } else if (c.type === 'bell') {
      // Golden Temple Bell (Ghanti)
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.moveTo(cx - 8, cy + 8);
      ctx.quadraticCurveTo(cx - 10, cy - 4, cx - 4, cy - 10);
      ctx.lineTo(cx + 4, cy - 10);
      ctx.quadraticCurveTo(cx + 10, cy - 4, cx + 8, cy + 8);
      ctx.closePath();
      ctx.fill();

      ctx.strokeStyle = '#fbbf24';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Handle & Clapper
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(cx - 2, cy - 14, 4, 5);
      ctx.fillStyle = '#d97706';
      ctx.beginPath();
      ctx.arc(cx, cy + 10, 3, 0, Math.PI * 2);
      ctx.fill();
    } else if (c.type === 'flower') {
      // Fragrant Marigold flower
      ctx.fillStyle = '#f97316';
      for (let i = 0; i < 8; i++) {
        const angle = (i / 8) * Math.PI * 2;
        const fx = cx + Math.cos(angle) * 7;
        const fy = cy + Math.sin(angle) * 7;
        ctx.beginPath();
        ctx.arc(fx, fy, 4.5, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = '#fef08a';
      ctx.beginPath();
      ctx.arc(cx, cy, 4, 0, Math.PI * 2);
      ctx.fill();
    } else if (c.type === 'heart') {
      // Recovery Heart
      ctx.fillStyle = '#ec4899';
      ctx.beginPath();
      ctx.moveTo(cx, cy + 6);
      ctx.bezierCurveTo(cx - 8, cy - 4, cx - 8, cy - 10, cx, cy - 4);
      ctx.bezierCurveTo(cx + 8, cy - 10, cx + 8, cy - 4, cx, cy + 6);
      ctx.fill();
      ctx.strokeStyle = '#fbcfe8';
      ctx.lineWidth = 1.5;
      ctx.stroke();
    } else if (c.type === 'powerup') {
      // Glowing Lotus Shield or Sky Dash orb
      ctx.fillStyle = '#ec4899';
      ctx.beginPath();
      ctx.arc(cx, cy, 14, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#fef08a';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Icon inside orb
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 12px Outfit, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('⚡', cx, cy);
    }

    ctx.restore();
  }

  // ==========================================
  // FESTIVAL EXIT GATE
  // ==========================================
  private drawFestivalGate(gate: LevelData['gate']) {
    const ctx = this.ctx;
    ctx.save();
    const cx = gate.x + gate.width / 2;
    const bottom = gate.y + gate.height;

    // Glowing holy portal arch
    const portalGrad = ctx.createRadialGradient(cx, bottom - 50, 10, cx, bottom - 50, 50);
    portalGrad.addColorStop(0, 'rgba(253, 224, 71, 0.85)');
    portalGrad.addColorStop(0.6, 'rgba(249, 115, 22, 0.5)');
    portalGrad.addColorStop(1, 'rgba(217, 119, 6, 0)');
    ctx.fillStyle = portalGrad;
    ctx.beginPath();
    ctx.arc(cx, bottom - 50, 50, Math.PI, 0);
    ctx.lineTo(cx + 50, bottom);
    ctx.lineTo(cx - 50, bottom);
    ctx.closePath();
    ctx.fill();

    // Ornate wooden / brass gopuram pillars
    ctx.fillStyle = '#b45309';
    ctx.fillRect(gate.x - 8, gate.y + 20, 16, gate.height - 20);
    ctx.fillRect(gate.x + gate.width - 8, gate.y + 20, 16, gate.height - 20);

    // Arch roof (Gopuram style)
    ctx.fillStyle = '#d97706';
    ctx.beginPath();
    ctx.moveTo(gate.x - 16, gate.y + 25);
    ctx.lineTo(cx, gate.y - 15);
    ctx.lineTo(gate.x + gate.width + 16, gate.y + 25);
    ctx.closePath();
    ctx.fill();

    // Golden Kalash pinnacle
    ctx.fillStyle = '#facc15';
    ctx.beginPath();
    ctx.arc(cx, gate.y - 18, 6, 0, Math.PI * 2);
    ctx.fill();

    // Hanging Toran garlands
    this.drawToranUnderPlatform(gate.x, gate.y + 28, gate.width);

    ctx.restore();
  }

  // ==========================================
  // PLAYER CHARACTER: MOOSHIKA!
  // ==========================================
  private drawMooshika(player: {
    x: number;
    y: number;
    width: number;
    height: number;
    vx: number;
    vy: number;
    facing: 1 | -1;
    isGrounded: boolean;
    isDashing: boolean;
    isWallSliding: boolean;
    wallSlideDir: number;
    invulnerableTimer: number;
    activeShield: boolean;
    hasModakaPower: boolean;
    hasDivineLight: boolean;
    squash: number;
  }) {
    const ctx = this.ctx;
    ctx.save();

    // Invulnerability blink
    if (player.invulnerableTimer > 0 && Math.floor(player.invulnerableTimer / 4) % 2 === 0) {
      ctx.restore();
      return;
    }

    const cx = player.x + player.width / 2;
    const cy = player.y + player.height / 2;

    ctx.translate(cx, cy);

    // Squash and stretch physics
    ctx.scale(player.facing * (2 - player.squash), player.squash);

    // Dash speed aura & ghosting
    if (player.isDashing) {
      ctx.shadowColor = '#f59e0b';
      ctx.shadowBlur = 18;
    }

    // Lotus Shield floating halo
    if (player.activeShield) {
      ctx.save();
      ctx.rotate(this.animTimer * 2);
      ctx.strokeStyle = 'rgba(236, 72, 153, 0.75)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(0, 0, player.width * 0.85, 0, Math.PI * 2);
      ctx.stroke();

      // Floating lotus petals around shield
      ctx.fillStyle = '#fbcfe8';
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * Math.PI * 2;
        ctx.beginPath();
        ctx.arc(Math.cos(a) * player.width * 0.85, Math.sin(a) * player.width * 0.85, 5, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    // Modaka Power golden aura
    if (player.hasModakaPower) {
      ctx.strokeStyle = 'rgba(253, 224, 71, 0.8)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, player.width * 0.75, 0, Math.PI * 2);
      ctx.stroke();
    }

    // 1. Tail (Animated curved tail)
    ctx.save();
    ctx.strokeStyle = '#c49774';
    ctx.lineWidth = 3.5;
    ctx.lineCap = 'round';
    ctx.beginPath();
    const tailWiggle = Math.sin(this.animTimer * 6) * 6;
    ctx.moveTo(-player.width * 0.35, player.height * 0.2);
    ctx.quadraticCurveTo(-player.width * 0.7, player.height * 0.1 + tailWiggle, -player.width * 0.85, -player.height * 0.15 + tailWiggle);
    ctx.stroke();
    ctx.restore();

    // 2. Legs / Paws (Running cycle or Jump tuck)
    const runCycle = player.isGrounded && Math.abs(player.vx) > 0.2 ? Math.sin(this.animTimer * 16) * 6 : 0;
    ctx.fillStyle = '#a77652';
    // Back Paw
    ctx.beginPath();
    ctx.ellipse(-player.width * 0.2 + runCycle, player.height * 0.42, 6, 4, 0, 0, Math.PI * 2);
    ctx.fill();
    // Front Paw
    ctx.beginPath();
    ctx.ellipse(player.width * 0.2 - runCycle, player.height * 0.42, 6, 4, 0, 0, Math.PI * 2);
    ctx.fill();

    // 3. Body (Cute chubby mouse torso)
    ctx.fillStyle = '#b8865d'; // warm mouse brown
    ctx.beginPath();
    ctx.ellipse(0, player.height * 0.1, player.width * 0.4, player.height * 0.35, 0, 0, Math.PI * 2);
    ctx.fill();

    // Light peach belly
    ctx.fillStyle = '#fce7d2';
    ctx.beginPath();
    ctx.ellipse(player.width * 0.08, player.height * 0.15, player.width * 0.24, player.height * 0.24, 0, 0, Math.PI * 2);
    ctx.fill();

    // 4. Festive Saffron Sash / Angavastram (Draped over shoulder)
    ctx.fillStyle = '#f97316';
    ctx.beginPath();
    ctx.moveTo(-player.width * 0.25, -player.height * 0.05);
    ctx.lineTo(player.width * 0.15, player.height * 0.28);
    ctx.lineTo(player.width * 0.05, player.height * 0.35);
    ctx.lineTo(-player.width * 0.35, player.height * 0.02);
    ctx.closePath();
    ctx.fill();
    // Gold border on sash
    ctx.strokeStyle = '#facc15';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Trailing scarf end flowing with movement
    const scarfFlap = Math.sin(this.animTimer * 12) * 5;
    ctx.fillStyle = '#f97316';
    ctx.beginPath();
    ctx.moveTo(-player.width * 0.25, -player.height * 0.02);
    ctx.quadraticCurveTo(-player.width * 0.55 - Math.abs(player.vx) * 2, -player.height * 0.05 + scarfFlap, -player.width * 0.7 - Math.abs(player.vx) * 3, scarfFlap);
    ctx.lineTo(-player.width * 0.65 - Math.abs(player.vx) * 3, scarfFlap + 6);
    ctx.lineTo(-player.width * 0.25, player.height * 0.08);
    ctx.closePath();
    ctx.fill();

    // 5. Head
    ctx.fillStyle = '#b8865d';
    ctx.beginPath();
    ctx.ellipse(player.width * 0.15, -player.height * 0.15, player.width * 0.35, player.height * 0.3, 0, 0, Math.PI * 2);
    ctx.fill();

    // 6. Cute Mouse Ears
    // Back Ear
    ctx.fillStyle = '#9f6f47';
    ctx.beginPath();
    ctx.arc(-player.width * 0.08, -player.height * 0.38, player.width * 0.24, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#f472b6'; // pink inner ear
    ctx.beginPath();
    ctx.arc(-player.width * 0.08, -player.height * 0.38, player.width * 0.15, 0, Math.PI * 2);
    ctx.fill();

    // Front Ear
    ctx.fillStyle = '#b8865d';
    ctx.beginPath();
    ctx.arc(player.width * 0.1, -player.height * 0.42, player.width * 0.25, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#f472b6';
    ctx.beginPath();
    ctx.arc(player.width * 0.1, -player.height * 0.42, player.width * 0.16, 0, Math.PI * 2);
    ctx.fill();

    // 7. Expressive Dark Eye with catchlights
    ctx.fillStyle = '#1e1b4b';
    ctx.beginPath();
    ctx.arc(player.width * 0.25, -player.height * 0.18, 4.5, 0, Math.PI * 2);
    ctx.fill();
    // Eye shine
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(player.width * 0.27, -player.height * 0.21, 1.8, 0, Math.PI * 2);
    ctx.arc(player.width * 0.22, -player.height * 0.16, 1, 0, Math.PI * 2);
    ctx.fill();

    // 8. Snout & Nose
    ctx.fillStyle = '#fce7d2';
    ctx.beginPath();
    ctx.ellipse(player.width * 0.38, -player.height * 0.1, 7, 5, 0, 0, Math.PI * 2);
    ctx.fill();
    // Cute pink nose tip
    ctx.fillStyle = '#f43f5e';
    ctx.beginPath();
    ctx.arc(player.width * 0.44, -player.height * 0.12, 2.8, 0, Math.PI * 2);
    ctx.fill();

    // 9. Twitching Whiskers
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.75)';
    ctx.lineWidth = 1;
    const whiskerTwitch = Math.sin(this.animTimer * 10) * 1.5;
    // Top whisker
    ctx.beginPath();
    ctx.moveTo(player.width * 0.38, -player.height * 0.12);
    ctx.lineTo(player.width * 0.62, -player.height * 0.18 + whiskerTwitch);
    // Bottom whisker
    ctx.moveTo(player.width * 0.38, -player.height * 0.08);
    ctx.lineTo(player.width * 0.6, -player.height * 0.04 + whiskerTwitch);
    ctx.stroke();

    // 10. Sacred Kumkum / Tilak on forehead
    ctx.fillStyle = '#dc2626';
    ctx.beginPath();
    ctx.arc(player.width * 0.18, -player.height * 0.28, 2.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#facc15';
    ctx.beginPath();
    ctx.arc(player.width * 0.18, -player.height * 0.24, 1.4, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  // ==========================================
  // ENEMIES & BOSSES
  // ==========================================
  private drawEnemy(e: Enemy) {
    if (e.isDefeated && e.defeatTimer <= 0) return;
    const ctx = this.ctx;
    ctx.save();

    const cx = e.x + e.width / 2;
    const cy = e.y + e.height / 2;

    ctx.translate(cx, cy);

    // Stunned star indicator
    if (e.stunTimer > 0) {
      ctx.fillStyle = '#facc15';
      const starRot = this.animTimer * 8;
      for (let i = 0; i < 3; i++) {
        const sa = starRot + (i / 3) * Math.PI * 2;
        ctx.beginPath();
        ctx.arc(Math.cos(sa) * 18, -e.height * 0.6 + Math.sin(sa) * 6, 3, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    if (e.isBoss) {
      this.drawBoss(e);
      ctx.restore();
      return;
    }

    // Standard shadow minion rendering
    ctx.scale(e.facing, 1);

    // Dark smoke aura
    ctx.fillStyle = 'rgba(76, 29, 149, 0.35)';
    ctx.beginPath();
    ctx.arc(0, 0, e.width * 0.65, 0, Math.PI * 2);
    ctx.fill();

    // Shadow Creature Body
    ctx.fillStyle = '#1e1035';
    ctx.beginPath();
    ctx.ellipse(0, 0, e.width * 0.45, e.height * 0.45, 0, 0, Math.PI * 2);
    ctx.fill();

    // Glowing Purple/Red Eyes
    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.arc(e.width * 0.15, -e.height * 0.1, 3.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(e.width * 0.16, -e.height * 0.12, 1.2, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  private drawBoss(e: Enemy) {
    const ctx = this.ctx;
    // Scale and pulsate
    const pulse = Math.sin(this.animTimer * 5) * 3;

    // Menacing Boss Shadow Aura
    const aura = ctx.createRadialGradient(0, 0, 10, 0, 0, e.width * 0.9);
    aura.addColorStop(0, 'rgba(126, 34, 206, 0.7)');
    aura.addColorStop(0.7, 'rgba(88, 28, 135, 0.4)');
    aura.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = aura;
    ctx.beginPath();
    ctx.arc(0, 0, e.width * 0.9 + pulse, 0, Math.PI * 2);
    ctx.fill();

    // Large Shadow Demon Body
    ctx.fillStyle = '#0f051d';
    ctx.beginPath();
    ctx.ellipse(0, 0, e.width * 0.48, e.height * 0.48, 0, 0, Math.PI * 2);
    ctx.fill();

    // Dark horned crown
    ctx.fillStyle = '#581c87';
    ctx.beginPath();
    ctx.moveTo(-e.width * 0.35, -e.height * 0.2);
    ctx.lineTo(-e.width * 0.45, -e.height * 0.7);
    ctx.lineTo(-e.width * 0.18, -e.height * 0.4);
    ctx.lineTo(0, -e.height * 0.75);
    ctx.lineTo(e.width * 0.18, -e.height * 0.4);
    ctx.lineTo(e.width * 0.45, -e.height * 0.7);
    ctx.lineTo(e.width * 0.35, -e.height * 0.2);
    ctx.closePath();
    ctx.fill();

    // Blazing Eyes
    ctx.fillStyle = '#dc2626';
    ctx.beginPath();
    ctx.arc(-e.width * 0.15, -e.height * 0.08, 6, 0, Math.PI * 2);
    ctx.arc(e.width * 0.15, -e.height * 0.08, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.arc(-e.width * 0.14, -e.height * 0.09, 2.5, 0, Math.PI * 2);
    ctx.arc(e.width * 0.16, -e.height * 0.09, 2.5, 0, Math.PI * 2);
    ctx.fill();

    // Boss Floating Claw Hands
    const handWiggle = Math.sin(this.animTimer * 4) * 8;
    ctx.fillStyle = '#3b0764';
    ctx.beginPath();
    ctx.arc(-e.width * 0.65, handWiggle, 12, 0, Math.PI * 2);
    ctx.arc(e.width * 0.65, -handWiggle, 12, 0, Math.PI * 2);
    ctx.fill();
  }

  // ==========================================
  // PROJECTILES & ATTACKS
  // ==========================================
  private drawProjectile(p: { x: number; y: number; width: number; height: number; type: string }) {
    const ctx = this.ctx;
    ctx.save();
    const cx = p.x + p.width / 2;
    const cy = p.y + p.height / 2;

    if (p.type === 'shockwave') {
      // Golden or shadow shockwave ring along ground
      ctx.strokeStyle = '#dc2626';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.ellipse(cx, cy, p.width / 2, p.height / 2, 0, 0, Math.PI * 2);
      ctx.stroke();
    } else {
      // Dark shadow bolt
      const grad = ctx.createRadialGradient(cx, cy, 2, cx, cy, p.width / 2);
      grad.addColorStop(0, '#ef4444');
      grad.addColorStop(0.5, '#7c3aed');
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(cx, cy, p.width / 2, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  // ==========================================
  // PARTICLES
  // ==========================================
  private drawParticles(particles: Particle[]) {
    const ctx = this.ctx;
    ctx.save();
    particles.forEach(p => {
      ctx.globalAlpha = Math.max(0, p.alpha);
      ctx.fillStyle = p.color;

      if (p.shape === 'petal') {
        // Floating Marigold / Rose petal
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation || 0);
        ctx.beginPath();
        ctx.ellipse(0, 0, p.size * 1.6, p.size * 0.8, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      } else if (p.shape === 'star') {
        // 4-point golden sparkle
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Round spark / smoke
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }
    });
    ctx.restore();
  }

  // ==========================================
  // FLOATING TEXTS (+10, MODAKA!, COMBO!)
  // ==========================================
  private drawFloatingTexts(texts: FloatingText[]) {
    const ctx = this.ctx;
    ctx.save();
    texts.forEach(t => {
      ctx.globalAlpha = Math.max(0, t.alpha);
      ctx.fillStyle = t.color;
      ctx.font = `bold ${t.fontSize || 16}px 'Baloo 2', cursive, sans-serif`;
      ctx.textAlign = 'center';
      ctx.lineWidth = 3;
      ctx.strokeStyle = '#000000';
      ctx.strokeText(t.text, t.x, t.y);
      ctx.fillText(t.text, t.x, t.y);
    });
    ctx.restore();
  }

  // ==========================================
  // AMBIENT LIGHTING & SHADOW CAVE OVERLAY
  // ==========================================
  private drawLightingOverlay(
    level: LevelData,
    cameraX: number,
    cameraY: number,
    player: { x: number; y: number; width: number; height: number; hasDivineLight: boolean }
  ) {
    // Only apply in levels with reduced ambient light (e.g. Level 8 Shadow Cave)
    if (level.ambientLighting !== undefined && level.ambientLighting < 0.8) {
      const ctx = this.ctx;
      const w = CANVAS_WIDTH;
      const h = CANVAS_HEIGHT;

      ctx.save();
      // Offscreen darkness mask using destination-out
      ctx.fillStyle = `rgba(10, 5, 20, ${1.0 - level.ambientLighting})`;
      ctx.fillRect(0, 0, w, h);

      // Cut out light around player
      ctx.globalCompositeOperation = 'destination-out';

      const playerScreenX = player.x + player.width / 2 - cameraX;
      const playerScreenY = player.y + player.height / 2 - cameraY;
      const playerLightRadius = player.hasDivineLight ? 280 : 130;

      const playerGlow = ctx.createRadialGradient(
        playerScreenX,
        playerScreenY,
        15,
        playerScreenX,
        playerScreenY,
        playerLightRadius
      );
      playerGlow.addColorStop(0, 'rgba(0, 0, 0, 1)');
      playerGlow.addColorStop(0.7, 'rgba(0, 0, 0, 0.8)');
      playerGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = playerGlow;
      ctx.beginPath();
      ctx.arc(playerScreenX, playerScreenY, playerLightRadius, 0, Math.PI * 2);
      ctx.fill();

      // Cut out light around lit lamps in level
      if (level.lamps) {
        level.lamps.forEach(lamp => {
          if (lamp.lit) {
            const lampScreenX = lamp.x + lamp.width / 2 - cameraX;
            const lampScreenY = lamp.y + lamp.height / 2 - cameraY;
            const lampGlow = ctx.createRadialGradient(
              lampScreenX,
              lampScreenY,
              10,
              lampScreenX,
              lampScreenY,
              lamp.radius
            );
            lampGlow.addColorStop(0, 'rgba(0, 0, 0, 1)');
            lampGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
            ctx.fillStyle = lampGlow;
            ctx.beginPath();
            ctx.arc(lampScreenX, lampScreenY, lamp.radius, 0, Math.PI * 2);
            ctx.fill();
          }
        });
      }

      ctx.restore();
    }
  }
}
