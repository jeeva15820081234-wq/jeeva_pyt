/**
 * Mooshika: The Festival Guardian - Game Engine
 * Handles physics, collisions, enemy AI, boss mechanics, combos and level states.
 */

import { LevelData, PlayerStats, Particle, FloatingText, ActivePowerUp, Platform, Enemy, LevelProgress, Achievement } from './types';
import { PHYSICS, CANVAS_WIDTH, CANVAS_HEIGHT } from './constants';
import { sound } from './sound';

export interface InputState {
  left: boolean;
  right: boolean;
  up: boolean;
  down: boolean;
  jump: boolean;
  dash: boolean;
  special: boolean;
}

export class GameEngine {
  public level: LevelData;
  public stats: PlayerStats;
  public progress: LevelProgress[];
  public achievements: Achievement[];
  public activePowerUps: ActivePowerUp[] = [];

  // Player physics state
  public player = {
    x: 100,
    y: 300,
    width: 32,
    height: 32,
    vx: 0,
    vy: 0,
    facing: 1 as 1 | -1,
    isGrounded: false,
    canDoubleJump: true,
    isDashing: false,
    dashTimer: 0,
    dashCooldown: 0,
    isWallSliding: false,
    wallSlideDir: 0,
    invulnerableTimer: 0,
    activeShield: false,
    hasModakaPower: false,
    hasDivineLight: false,
    squash: 1.0,
    checkpoint: { x: 100, y: 300 },
  };

  // Camera & Visuals
  public cameraX = 0;
  public cameraY = 0;
  public screenShake = { x: 0, y: 0, intensity: 0, timer: 0 };
  public particles: Particle[] = [];
  public floatingTexts: FloatingText[] = [];
  public projectiles: Array<{ x: number; y: number; vx: number; vy: number; width: number; height: number; type: string; life: number }> = [];

  // Boss state
  public activeBoss: Enemy | null = null;
  public bossAttackTimer: number = 0;

  // Level statistics
  public levelTime: number = 0;
  public levelModakasFound: number = 0;
  public levelComplete: boolean = false;
  public isGameOver: boolean = false;

  // Platforming responsiveness helpers (coyote time & jump buffer)
  private prevInput: InputState = {
    left: false,
    right: false,
    up: false,
    down: false,
    jump: false,
    dash: false,
    special: false,
  };
  private coyoteTimer: number = 0;
  private jumpBufferTimer: number = 0;

  // Callbacks
  public onLevelComplete?: (stars: number, score: number) => void;
  public onGameOver?: () => void;
  public onAchievementUnlocked?: (ach: Achievement) => void;

  constructor(
    level: LevelData,
    stats: PlayerStats,
    progress: LevelProgress[],
    achievements: Achievement[]
  ) {
    this.level = JSON.parse(JSON.stringify(level)); // deep clone
    this.stats = stats;
    this.progress = progress;
    this.achievements = achievements;
    this.initLevel();
  }

  public initLevel() {
    this.player.x = this.level.playerStart.x;
    this.player.y = this.level.playerStart.y;
    this.player.checkpoint = { ...this.level.playerStart };
    this.player.vx = 0;
    this.player.vy = 0;
    this.player.isGrounded = false;
    this.player.canDoubleJump = true;
    this.player.isDashing = false;
    this.player.dashTimer = 0;
    this.player.dashCooldown = 0;
    this.player.invulnerableTimer = 0;
    this.player.activeShield = false;
    this.player.hasModakaPower = false;
    this.player.hasDivineLight = false;
    this.player.squash = 1.0;

    this.levelTime = 0;
    this.levelModakasFound = 0;
    this.levelComplete = false;
    this.isGameOver = false;
    this.particles = [];
    this.floatingTexts = [];
    this.projectiles = [];
    this.activePowerUps = [];

    // Initialize Boss if present
    if (this.level.boss) {
      this.activeBoss = {
        id: 'level_boss',
        type: this.level.boss.type,
        x: this.level.boss.x,
        y: this.level.boss.y,
        width: 58,
        height: 56,
        vx: 1.2,
        vy: 0,
        facing: -1,
        minX: this.level.boss.x - 200,
        maxX: this.level.boss.x + 200,
        health: this.level.boss.maxHealth,
        maxHealth: this.level.boss.maxHealth,
        stunTimer: 0,
        isDefeated: false,
        defeatTimer: 0,
        animFrame: 0,
        attackCooldown: 120,
        isBoss: true,
        bossName: this.level.boss.name,
        bossPhase: 1,
      };
      this.level.enemies.push(this.activeBoss);
    } else {
      this.activeBoss = null;
    }
  }

  // ==========================================
  // MAIN UPDATE LOOP
  // ==========================================
  public update(input: InputState) {
    if (this.levelComplete || this.isGameOver) return;

    this.levelTime += 1 / 60;

    // Update screen shake
    if (this.screenShake.timer > 0) {
      this.screenShake.timer--;
      this.screenShake.x = (Math.random() - 0.5) * this.screenShake.intensity;
      this.screenShake.y = (Math.random() - 0.5) * this.screenShake.intensity;
    } else {
      this.screenShake.x = 0;
      this.screenShake.y = 0;
    }

    // Update powerups
    this.updatePowerUps();

    // Update player movement & physics
    this.updatePlayer(input);

    // Update platforms (moving carts, crumbling, switches)
    this.updatePlatforms();

    // Update lamps & light radius in cave
    this.updateLamps();

    // Update enemies & boss AI
    this.updateEnemies();

    // Update projectiles
    this.updateProjectiles();

    // Check collisions with collectibles & hazards
    this.checkCollectibleCollisions();
    this.checkHazardCollisions();

    // Check level exit gate
    this.checkLevelGate();

    // Update combo timer
    if (this.stats.comboTimer > 0) {
      this.stats.comboTimer--;
      if (this.stats.comboTimer <= 0) {
        this.stats.combo = 1;
      }
    }

    // Update ambient particles & floating texts
    this.updateParticles();
    this.updateFloatingTexts();

    // Update Camera (smooth lerp follow)
    this.updateCamera();

    // Store previous input for edge-trigger detection
    this.prevInput = { ...input };
  }

  // ==========================================
  // POWER-UPS
  // ==========================================
  private updatePowerUps() {
    this.player.hasModakaPower = false;
    this.player.hasDivineLight = false;

    for (let i = this.activePowerUps.length - 1; i >= 0; i--) {
      const p = this.activePowerUps[i];
      p.duration -= 1 / 60;

      if (p.type === 'modaka_power') this.player.hasModakaPower = true;
      if (p.type === 'divine_light') {
        this.player.hasDivineLight = true;
        // Reveal hidden platforms
        this.level.platforms.forEach(plat => {
          if (plat.type === 'hidden') plat.revealed = true;
        });
      }

      if (p.duration <= 0) {
        this.activePowerUps.splice(i, 1);
      }
    }
  }

  public activatePowerUp(type: ActivePowerUp['type']) {
    sound.playPowerUp();
    if (type === 'lotus_shield') {
      this.player.activeShield = true;
      this.addFloatingText(this.player.x, this.player.y - 20, 'LOTUS SHIELD!', '#ec4899', 20);
      return;
    }

    const duration = type === 'golden_bell' ? 6 : 10;
    this.activePowerUps = this.activePowerUps.filter(p => p.type !== type);
    this.activePowerUps.push({ type, duration, maxDuration: duration });

    if (type === 'golden_bell') {
      // Stun all enemies
      this.level.enemies.forEach(e => {
        e.stunTimer = 180;
      });
      this.addFloatingText(this.player.x, this.player.y - 20, 'ENEMIES FROZEN!', '#fbbf24', 20);
    } else if (type === 'modaka_power') {
      this.addFloatingText(this.player.x, this.player.y - 20, 'MODAKA SPEED!', '#f59e0b', 20);
    } else if (type === 'divine_light') {
      this.addFloatingText(this.player.x, this.player.y - 20, 'DIVINE LIGHT!', '#facc15', 20);
    } else if (type === 'festival_dash') {
      this.addFloatingText(this.player.x, this.player.y - 20, 'FESTIVAL DASH!', '#f97316', 20);
    }
  }

  // ==========================================
  // PLAYER MOVEMENT & PHYSICS
  // ==========================================
  private updatePlayer(input: InputState) {
    const p = this.player;
    if (p.invulnerableTimer > 0) p.invulnerableTimer--;
    if (p.dashCooldown > 0) p.dashCooldown--;

    const jumpJustPressed = input.jump && !this.prevInput.jump;
    const dashJustPressed = input.dash && !this.prevInput.dash;
    const specialJustPressed = input.special && !this.prevInput.special;

    // Buffer jump input
    if (jumpJustPressed) {
      this.jumpBufferTimer = 7;
    } else if (this.jumpBufferTimer > 0) {
      this.jumpBufferTimer--;
    }

    // Update coyote time
    if (p.isGrounded) {
      this.coyoteTimer = 6;
    } else if (this.coyoteTimer > 0) {
      this.coyoteTimer--;
    }

    // Squash normalization
    p.squash += (1.0 - p.squash) * 0.15;

    // 1. Dash handling (triggers on press)
    if ((dashJustPressed || (input.dash && !this.prevInput.dash)) && !p.isDashing && p.dashCooldown <= 0) {
      p.isDashing = true;
      p.dashTimer = PHYSICS.DASH_DURATION;
      p.dashCooldown = PHYSICS.DASH_COOLDOWN;
      sound.playDash();
      this.triggerScreenShake(3, 8);
      // Spawn festive dash spark particles
      for (let i = 0; i < 12; i++) {
        this.particles.push({
          x: p.x + p.width / 2,
          y: p.y + p.height / 2,
          vx: -p.facing * (Math.random() * 4 + 2),
          vy: (Math.random() - 0.5) * 3,
          size: Math.random() * 4 + 2,
          color: '#fbbf24',
          alpha: 1.0,
          maxLife: 20,
          life: 20,
          shape: 'spark',
        });
      }
    }

    if (p.isDashing) {
      p.dashTimer--;
      p.vx = p.facing * PHYSICS.DASH_SPEED;
      p.vy = 0; // maintain horizontal glide during dash

      // Trail afterimage particle
      if (p.dashTimer % 2 === 0) {
        this.particles.push({
          x: p.x + p.width / 2,
          y: p.y + p.height / 2,
          vx: 0,
          vy: 0,
          size: 6,
          color: '#f97316',
          alpha: 0.7,
          maxLife: 14,
          life: 14,
          shape: 'circle',
        });
      }

      if (p.dashTimer <= 0) {
        p.isDashing = false;
        p.vx *= 0.5;
      }
    } else {
      // Normal horizontal movement
      const maxSpeed = p.hasModakaPower ? PHYSICS.RUN_SPEED * 1.4 : PHYSICS.RUN_SPEED;
      if (input.left) {
        p.vx = Math.max(p.vx - PHYSICS.RUN_ACCEL, -maxSpeed);
        p.facing = -1;
      } else if (input.right) {
        p.vx = Math.min(p.vx + PHYSICS.RUN_ACCEL, maxSpeed);
        p.facing = 1;
      } else {
        p.vx *= PHYSICS.RUN_DECEL;
        if (Math.abs(p.vx) < 0.1) p.vx = 0;
      }

      // Gravity & Wind
      let gravity = PHYSICS.GRAVITY;
      if (this.level.wind) {
        p.vx += this.level.wind.vx * 0.1;
        p.vy += this.level.wind.vy * 0.1;
      }

      // Wall Slide
      if (p.isWallSliding && p.vy > 0) {
        p.vy = Math.min(p.vy + gravity * 0.4, PHYSICS.WALL_SLIDE_SPEED);
      } else {
        p.vy = Math.min(p.vy + gravity, PHYSICS.MAX_FALL_SPEED);
      }

      // Jump & Double Jump Handling
      if (this.jumpBufferTimer > 0) {
        if (p.isGrounded || this.coyoteTimer > 0) {
          // Ground Jump (also works during coyote window)
          p.vy = PHYSICS.JUMP_FORCE;
          p.isGrounded = false;
          this.coyoteTimer = 0;
          this.jumpBufferTimer = 0;
          p.canDoubleJump = true;
          p.squash = 0.75; // stretch upwards
          sound.playJump();
        } else if (p.isWallSliding) {
          // Wall Jump
          p.vy = PHYSICS.WALL_JUMP_FORCE_Y;
          p.vx = -p.wallSlideDir * PHYSICS.WALL_JUMP_FORCE_X;
          p.facing = -p.wallSlideDir as 1 | -1;
          p.isWallSliding = false;
          this.jumpBufferTimer = 0;
          p.canDoubleJump = true;
          p.squash = 0.8;
          sound.playJump();
        } else if (jumpJustPressed && p.canDoubleJump) {
          // Double Jump (requires an intentional fresh press in air)
          p.vy = PHYSICS.DOUBLE_JUMP_FORCE;
          p.canDoubleJump = false;
          this.jumpBufferTimer = 0;
          p.squash = 0.8;
          sound.playDoubleJump();
          // Twirl star particles
          for (let i = 0; i < 8; i++) {
            this.particles.push({
              x: p.x + p.width / 2,
              y: p.y + p.height,
              vx: (Math.random() - 0.5) * 4,
              vy: Math.random() * 2,
              size: 3,
              color: '#facc15',
              alpha: 1,
              maxLife: 18,
              life: 18,
              shape: 'star',
            });
          }
        }
      }

      // Variable jump height: release jump early to cut upward velocity
      if (!input.jump && p.vy < -3) {
        p.vy *= 0.65;
      }

      // Special Bell Attack (requires fresh press and sufficient energy)
      if (specialJustPressed && this.stats.festivalEnergy >= 25) {
        this.performSpecialBellAttack();
      }
    }

    // Apply horizontal & vertical movement with collision detection
    this.resolveMovementAndCollisions();
  }

  private performSpecialBellAttack() {
    this.stats.festivalEnergy -= 25;
    sound.playBell();
    this.triggerScreenShake(4, 12);
    this.addFloatingText(this.player.x, this.player.y - 25, 'BELL PURIFICATION!', '#fbbf24', 20);

    // Blast wave particles
    for (let i = 0; i < 24; i++) {
      const angle = (i / 24) * Math.PI * 2;
      this.particles.push({
        x: this.player.x + this.player.width / 2,
        y: this.player.y + this.player.height / 2,
        vx: Math.cos(angle) * 7,
        vy: Math.sin(angle) * 7,
        size: 5,
        color: '#fef08a',
        alpha: 1,
        maxLife: 24,
        life: 24,
        shape: 'star',
      });
    }

    // Stun and damage all enemies on screen
    this.level.enemies.forEach(e => {
      const dx = Math.abs(e.x - this.player.x);
      const dy = Math.abs(e.y - this.player.y);
      if (dx < 350 && dy < 250) {
        e.stunTimer = 160;
        e.health -= 1;
        if (e.health <= 0) {
          this.defeatEnemy(e);
        }
      }
    });

    // Clear nearby projectiles
    this.projectiles = this.projectiles.filter(p => {
      const dx = Math.abs(p.x - this.player.x);
      return dx > 350;
    });
  }

  // ==========================================
  // COLLISION RESOLUTION
  // ==========================================
  private resolveMovementAndCollisions() {
    const p = this.player;

    // 1. Move X and check solid walls
    p.x += p.vx;
    p.isWallSliding = false;
    p.wallSlideDir = 0;

    for (const plat of this.level.platforms) {
      if (plat.type === 'hidden' && !plat.revealed) continue;
      if (plat.type === 'one_way') continue; // one-way platforms do not block sides

      if (this.checkAABB(p, plat)) {
        if (p.vx > 0) {
          p.x = plat.x - p.width;
          p.wallSlideDir = 1;
        } else if (p.vx < 0) {
          p.x = plat.x + plat.width;
          p.wallSlideDir = -1;
        }
        p.vx = 0;

        // Check if against a wall while falling for Wall Slide
        if (!p.isGrounded && p.vy > 0) {
          p.isWallSliding = true;
        }
      }
    }

    // Level horizontal bounds
    if (p.x < 0) {
      p.x = 0;
      p.vx = 0;
    }
    if (p.x + p.width > this.level.width) {
      p.x = this.level.width - p.width;
      p.vx = 0;
    }

    // 2. Move Y and check ground / ceiling collisions
    const prevY = p.y;
    p.y += p.vy;
    p.isGrounded = false;

    for (const plat of this.level.platforms) {
      if (plat.type === 'hidden' && !plat.revealed) continue;

      if (this.checkAABB(p, plat)) {
        // Falling down onto platform top
        if (p.vy > 0 && prevY + p.height <= plat.y + 12) {
          p.y = plat.y - p.height;
          p.isGrounded = true;
          p.canDoubleJump = true;
          p.squash = 1.25; // squash on landing
          this.coyoteTimer = 6;

          // If a jump was buffered just before touchdown, execute immediately
          if (this.jumpBufferTimer > 0) {
            p.vy = PHYSICS.JUMP_FORCE;
            p.isGrounded = false;
            this.jumpBufferTimer = 0;
            this.coyoteTimer = 0;
            p.squash = 0.75;
            sound.playJump();
          } else {
            // Check special platform mechanics
            if (plat.type === 'drum') {
            // Drum bounce!
            p.vy = PHYSICS.DRUM_BOUNCE_FORCE;
            p.isGrounded = false;
            sound.playDrumBounce();
            this.triggerScreenShake(4, 10);
            this.addCombo();
            this.addFloatingText(plat.x + plat.width / 2, plat.y - 15, 'DRUM BOUNCE!', '#ef4444', 18);
          } else if (plat.type === 'bouncy_lotus') {
            // Lotus bounce!
            p.vy = PHYSICS.BOUNCY_LOTUS_FORCE;
            p.isGrounded = false;
            sound.playDoubleJump();
            this.addFloatingText(plat.x + plat.width / 2, plat.y - 15, 'LOTUS SPRING!', '#ec4899', 18);
          } else {
            p.vy = 0;
            // Transfer moving platform velocity
            if (plat.vx) p.x += plat.vx;
          }
        }
      } else if (p.vy < 0 && plat.type === 'solid') {
          // Hit head on solid ceiling
          p.y = plat.y + plat.height;
          p.vy = 0;
        }
      }
    }

    // Check bottom pit death
    if (p.y > this.level.height + 60) {
      this.playerTakeDamage(1, true);
    }
  }

  // ==========================================
  // PLATFORMS & PUZZLE SWITCHES
  // ==========================================
  private updatePlatforms() {
    this.level.platforms.forEach(plat => {
      // Moving platform updates
      if (plat.vx && plat.minX !== undefined && plat.maxX !== undefined) {
        plat.x += plat.vx;
        if (plat.x <= plat.minX || plat.x + plat.width >= plat.maxX) {
          plat.vx = -plat.vx;
        }
      }
      if (plat.vy && plat.minY !== undefined && plat.maxY !== undefined) {
        plat.y += plat.vy;
        if (plat.y <= plat.minY || plat.y >= plat.maxY) {
          plat.vy = -plat.vy;
        }
      }
    });

    // Switches
    if (this.level.switches) {
      this.level.switches.forEach(sw => {
        if (!sw.isPressed && this.checkAABB(this.player, sw)) {
          sw.isPressed = true;
          sound.playCoin();
          this.addFloatingText(sw.x, sw.y - 20, 'SWITCH ACTIVATED!', '#10b981', 16);
          // Trigger linked moving platform or bridge
          const target = this.level.platforms.find(p => p.type === 'moving' && p.y > 300);
          if (target) {
            target.vy = -1.5;
          }
        }
      });
    }
  }

  // ==========================================
  // LAMPS (Level 8 Shadow Cave)
  // ==========================================
  private updateLamps() {
    if (!this.level.lamps) return;
    this.level.lamps.forEach(lamp => {
      // Light up lamp when Mooshika passes near
      const dx = Math.abs((this.player.x + this.player.width / 2) - (lamp.x + lamp.width / 2));
      const dy = Math.abs((this.player.y + this.player.height / 2) - (lamp.y + lamp.height / 2));
      if (!lamp.lit && dx < 60 && dy < 60) {
        lamp.lit = true;
        sound.playCoin();
        this.addFloatingText(lamp.x, lamp.y - 20, 'LAMP LIT!', '#facc15', 18);
        // Reveal nearby hidden platforms
        this.level.platforms.forEach(plat => {
          if (plat.type === 'hidden') {
            const pdx = Math.abs(plat.x - lamp.x);
            if (pdx < lamp.radius) plat.revealed = true;
          }
        });
      }
    });
  }

  // ==========================================
  // ENEMIES & BOSS AI
  // ==========================================
  private updateEnemies() {
    this.level.enemies.forEach(enemy => {
      if (enemy.isDefeated) {
        enemy.defeatTimer--;
        return;
      }

      if (enemy.stunTimer > 0) {
        enemy.stunTimer--;
        return;
      }

      // Patrol movement
      if (enemy.minX !== undefined && enemy.maxX !== undefined) {
        enemy.x += enemy.vx * enemy.facing;
        if (enemy.x <= enemy.minX) {
          enemy.facing = 1;
        } else if (enemy.x + enemy.width >= enemy.maxX) {
          enemy.facing = -1;
        }
      }

      // Boss special attacks
      if (enemy.isBoss) {
        this.updateBossBehavior(enemy);
      }

      // Collision with Player
      if (this.checkAABB(this.player, enemy)) {
        // Stomp condition: player is falling down and player's feet hit top half of enemy
        const isStomp = this.player.vy > 0 && (this.player.y + this.player.height <= enemy.y + enemy.height * 0.65);

        if (isStomp) {
          sound.playStomp();
          this.player.vy = -9.5; // bounce upward
          this.player.canDoubleJump = true;
          this.triggerScreenShake(3, 8);
          this.addCombo();
          enemy.health -= 1;
          this.addFloatingText(enemy.x, enemy.y - 15, 'STOMP! +50', '#fbbf24', 16);
          this.stats.score += 50 * this.stats.combo;

          if (enemy.health <= 0) {
            this.defeatEnemy(enemy);
          } else {
            enemy.stunTimer = 60; // stun boss/heavy enemy briefly
          }
        } else if (this.player.isDashing) {
          // Dash attack cleanses or damages enemy
          sound.playStomp();
          this.triggerScreenShake(4, 10);
          this.addCombo();
          enemy.health -= 2;
          this.addFloatingText(enemy.x, enemy.y - 15, 'DASH STRIKE! +100', '#f97316', 18);
          this.stats.score += 100 * this.stats.combo;

          if (enemy.health <= 0) {
            this.defeatEnemy(enemy);
          } else {
            enemy.stunTimer = 75;
          }
        } else {
          // Player takes damage
          this.playerTakeDamage(1);
        }
      }
    });
  }

  private updateBossBehavior(boss: Enemy) {
    boss.attackCooldown--;
    if (boss.attackCooldown <= 0) {
      sound.playBossAttack();
      this.triggerScreenShake(5, 14);

      // Level 10 Final Boss: THE SHADOW OF CHAOS shoots shadow bolts and shockwaves
      if (this.level.id === 10) {
        // Shockwave along ground
        this.projectiles.push({
          x: boss.x + (boss.facing === 1 ? boss.width : -20),
          y: boss.y + boss.height - 15,
          vx: boss.facing * -4.2,
          vy: 0,
          width: 32,
          height: 18,
          type: 'shockwave',
          life: 180,
        });

        // Elevated shadow bolt targeting player height
        this.projectiles.push({
          x: boss.x,
          y: boss.y + 10,
          vx: boss.facing * -3.6,
          vy: (this.player.y - boss.y) * 0.015,
          width: 22,
          height: 22,
          type: 'shadow_bolt',
          life: 160,
        });

        boss.attackCooldown = 110;
      } else {
        // Mini-bosses shoot single shadow bolt
        this.projectiles.push({
          x: boss.x,
          y: boss.y + boss.height / 2,
          vx: boss.facing * -3.8,
          vy: 0,
          width: 20,
          height: 20,
          type: 'shadow_bolt',
          life: 140,
        });
        boss.attackCooldown = 140;
      }
    }
  }

  private updateProjectiles() {
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const proj = this.projectiles[i];
      proj.x += proj.vx;
      proj.y += proj.vy;
      proj.life--;

      // Hit player
      if (this.checkAABB(this.player, proj)) {
        this.playerTakeDamage(1);
        this.projectiles.splice(i, 1);
        continue;
      }

      if (proj.life <= 0) {
        this.projectiles.splice(i, 1);
      }
    }
  }

  private defeatEnemy(enemy: Enemy) {
    enemy.isDefeated = true;
    enemy.defeatTimer = 30;
    sound.playBell();

    // Spawn shadow smoke purification particles
    for (let i = 0; i < 16; i++) {
      this.particles.push({
        x: enemy.x + enemy.width / 2,
        y: enemy.y + enemy.height / 2,
        vx: (Math.random() - 0.5) * 5,
        vy: (Math.random() - 0.5) * 5,
        size: Math.random() * 5 + 3,
        color: '#c084fc',
        alpha: 1.0,
        maxLife: 24,
        life: 24,
        shape: 'smoke',
      });
    }

    this.checkAchievement('shadow_hunter');

    if (enemy.isBoss) {
      this.stats.score += 500 * this.stats.combo;
      this.addFloatingText(enemy.x, enemy.y - 30, 'GUARDIAN PURIFIED! +500', '#f59e0b', 22);
      if (this.level.id === 10) {
        this.checkAchievement('festival_guardian');
      }
    }
  }

  // ==========================================
  // COLLECTIBLES & HAZARDS
  // ==========================================
  private checkCollectibleCollisions() {
    this.level.collectibles.forEach(col => {
      if (col.collected) return;

      if (this.checkAABB(this.player, col)) {
        col.collected = true;

        if (col.type === 'coin') {
          sound.playCoin();
          this.stats.coins += 1;
          this.stats.score += col.value * this.stats.combo;
          this.stats.festivalEnergy = Math.min(this.stats.maxFestivalEnergy, this.stats.festivalEnergy + 5);
          this.addCombo();
          this.addFloatingText(col.x, col.y - 15, `+${col.value * this.stats.combo}`, '#fbbf24', 16);
        } else if (col.type === 'modaka') {
          sound.playModaka();
          this.levelModakasFound += 1;
          this.stats.totalModakas += 1;
          this.stats.score += col.value * this.stats.combo;
          this.stats.festivalEnergy = Math.min(this.stats.maxFestivalEnergy, this.stats.festivalEnergy + 20);
          this.addCombo();
          this.addFloatingText(col.x, col.y - 25, 'SACRED MODAKA! +100', '#fef08a', 20);
          this.checkAchievement('first_modaka');

          // Celebration petals
          for (let i = 0; i < 14; i++) {
            this.particles.push({
              x: col.x + col.width / 2,
              y: col.y + col.height / 2,
              vx: (Math.random() - 0.5) * 4,
              vy: (Math.random() - 0.5) * 4 - 2,
              size: 4,
              color: '#f97316',
              alpha: 1,
              maxLife: 30,
              life: 30,
              shape: 'petal',
            });
          }
        } else if (col.type === 'flower') {
          sound.playCoin();
          this.stats.score += col.value * this.stats.combo;
          this.addCombo();
          this.addFloatingText(col.x, col.y - 15, `+${col.value}`, '#f97316', 16);
        } else if (col.type === 'bell') {
          sound.playBell();
          this.stats.totalBells += 1;
          this.stats.score += col.value * this.stats.combo;
          this.addCombo();
          this.addFloatingText(col.x, col.y - 15, 'FESTIVAL BELL! +50', '#fbbf24', 18);
          this.checkAchievement('bell_collector');
        } else if (col.type === 'heart') {
          sound.playCoin();
          this.stats.health = Math.min(this.stats.maxHealth, this.stats.health + 1);
          this.addFloatingText(col.x, col.y - 15, '+1 HEART!', '#ec4899', 18);
        } else if (col.type === 'powerup' && col.powerUpType) {
          this.activatePowerUp(col.powerUpType);
        }
      }
    });
  }

  private checkHazardCollisions() {
    this.level.hazards.forEach(haz => {
      if (this.checkAABB(this.player, haz)) {
        if (haz.type === 'water' || haz.type === 'spikes') {
          this.playerTakeDamage(1, true);
        } else {
          this.playerTakeDamage(1, false);
        }
      }
    });
  }

  // ==========================================
  // DAMAGE & RESPAWN
  // ==========================================
  public playerTakeDamage(amount: number, respawnAtCheckpoint = false) {
    if (this.player.invulnerableTimer > 0) return;

    // Shield absorbs hit
    if (this.player.activeShield) {
      this.player.activeShield = false;
      this.player.invulnerableTimer = PHYSICS.INVULNERABILITY_FRAMES;
      sound.playBell();
      this.triggerScreenShake(4, 10);
      this.addFloatingText(this.player.x, this.player.y - 20, 'SHIELD ABSORBED HIT!', '#ec4899', 18);
      return;
    }

    this.stats.health -= amount;
    this.stats.combo = 1; // reset combo multiplier
    this.player.invulnerableTimer = PHYSICS.INVULNERABILITY_FRAMES;
    this.player.squash = 0.6;
    sound.playHurt();
    this.triggerScreenShake(6, 14);

    if (this.stats.health <= 0) {
      this.stats.lives -= 1;
      if (this.stats.lives <= 0) {
        this.isGameOver = true;
        if (this.onGameOver) this.onGameOver();
        return;
      } else {
        // Recover health & respawn at checkpoint
        this.stats.health = this.stats.maxHealth;
        this.respawnAtCheckpoint();
      }
    } else if (respawnAtCheckpoint) {
      this.respawnAtCheckpoint();
    }
  }

  private respawnAtCheckpoint() {
    this.player.x = this.player.checkpoint.x;
    this.player.y = this.player.checkpoint.y;
    this.player.vx = 0;
    this.player.vy = 0;
  }

  // ==========================================
  // COMBO & ACHIEVEMENTS
  // ==========================================
  private addCombo() {
    this.stats.combo = Math.min(5, this.stats.combo + 1);
    this.stats.comboTimer = PHYSICS.COMBO_TIMEOUT_FRAMES;
    this.stats.maxCombo = Math.max(this.stats.maxCombo, this.stats.combo);
    if (this.stats.combo >= 5) {
      this.checkAchievement('combo_master');
    }
  }

  private checkAchievement(id: string) {
    const ach = this.achievements.find(a => a.id === id);
    if (ach && !ach.unlocked) {
      ach.unlocked = true;
      ach.unlockedAt = Date.now();
      sound.playAchievement();
      this.addFloatingText(this.player.x, this.player.y - 45, `🏆 ${ach.title}!`, '#facc15', 22);
      if (this.onAchievementUnlocked) {
        this.onAchievementUnlocked(ach);
      }
    }
  }

  // ==========================================
  // LEVEL COMPLETION
  // ==========================================
  private checkLevelGate() {
    if (this.checkAABB(this.player, this.level.gate)) {
      this.levelComplete = true;
      sound.playLevelComplete();

      // Calculate Stars (1 to 3)
      let stars = 1; // Completed
      if (this.levelModakasFound >= 3) stars = 2; // All 3 Modakas found
      if (this.levelModakasFound >= 3 && this.stats.health === this.stats.maxHealth) {
        stars = 3; // Perfect level!
        this.checkAchievement('perfect_level');
      }

      // Update progress
      const p = this.progress.find(pr => pr.levelId === this.level.id);
      if (p) {
        p.completed = true;
        p.stars = Math.max(p.stars, stars);
        p.highScore = Math.max(p.highScore, this.stats.score);
        p.modakasCollected = Math.max(p.modakasCollected, this.levelModakasFound);
        p.bestTime = p.bestTime === 0 ? this.levelTime : Math.min(p.bestTime, this.levelTime);
      }

      // Unlock next level
      const nextLevel = this.progress.find(pr => pr.levelId === this.level.id + 1);
      if (nextLevel) {
        nextLevel.unlocked = true;
      }

      if (this.onLevelComplete) {
        this.onLevelComplete(stars, this.stats.score);
      }
    }
  }

  // ==========================================
  // PARTICLES & FLOATING TEXTS
  // ==========================================
  private addFloatingText(x: number, y: number, text: string, color: string, fontSize = 16) {
    this.floatingTexts.push({
      x,
      y,
      text,
      color,
      alpha: 1.0,
      life: 45,
      maxLife: 45,
      vy: -1.2,
      fontSize,
    });
  }

  private updateParticles() {
    // Ambient falling petals occasionally
    if (Math.random() < 0.25) {
      this.particles.push({
        x: this.cameraX + Math.random() * CANVAS_WIDTH,
        y: this.cameraY - 10,
        vx: (Math.random() - 0.5) * 1.5,
        vy: Math.random() * 1.5 + 0.8,
        size: Math.random() * 3 + 2,
        color: Math.random() > 0.5 ? '#f97316' : '#ec4899',
        alpha: 0.8,
        maxLife: 180,
        life: 180,
        shape: 'petal',
        rotation: Math.random() * Math.PI * 2,
        vRot: (Math.random() - 0.5) * 0.08,
      });
    }

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      if (p.rotation !== undefined && p.vRot) p.rotation += p.vRot;
      p.life--;
      p.alpha = p.life / p.maxLife;

      if (p.life <= 0) {
        this.particles.splice(i, 1);
      }
    }
  }

  private updateFloatingTexts() {
    for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
      const t = this.floatingTexts[i];
      t.y += t.vy;
      t.life--;
      t.alpha = t.life / t.maxLife;
      if (t.life <= 0) {
        this.floatingTexts.splice(i, 1);
      }
    }
  }

  private triggerScreenShake(intensity: number, frames: number) {
    this.screenShake.intensity = intensity;
    this.screenShake.timer = frames;
  }

  // ==========================================
  // CAMERA FOLLOW
  // ==========================================
  private updateCamera() {
    // Target player center with lookahead
    const targetX = this.player.x + this.player.width / 2 - CANVAS_WIDTH * 0.45;
    const targetY = this.player.y + this.player.height / 2 - CANVAS_HEIGHT * 0.6;

    // Smooth Lerp
    this.cameraX += (targetX - this.cameraX) * 0.1;
    this.cameraY += (targetY - this.cameraY) * 0.1;

    // Clamp camera within level bounds
    this.cameraX = Math.max(0, Math.min(this.cameraX, this.level.width - CANVAS_WIDTH));
    this.cameraY = Math.max(0, Math.min(this.cameraY, this.level.height - CANVAS_HEIGHT));
  }

  // AABB Collision Helper
  private checkAABB(
    a: { x: number; y: number; width: number; height: number },
    b: { x: number; y: number; width: number; height: number }
  ): boolean {
    return (
      a.x < b.x + b.width &&
      a.x + a.width > b.x &&
      a.y < b.y + b.height &&
      a.y + a.height > b.y
    );
  }
}
